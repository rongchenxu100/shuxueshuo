# 几何表达简化：现有格式与模型输出格式审查

日期：2026-09-15。

状态：角相等、角比例的简洁方向已确认。根据最新审查，题内定义由 LLM 解读并在各小问中落实为通用基础 fact，撤回按题内定义预置组合类型的方案；另已确认：模型仅按题面字面层级放置条件、沿用原名，作用域处理交给代码；删除逐条来源关联及覆盖表。具体字段与其余项目供审查。本文没有修改运行代码、schema 或提示词，没有重新调用模型。

## 1. 本次修改的重点

LLM 输出数学含义明确、可确定性转换的简洁 fact；代码负责展开表达式、解析引用、生成内部 ID 和校验。内部是否使用 QuantityTerm，不再决定模型必须输出什么。

**已确认的实现基线是 2026-08-10 提交 `8d98800e` 引入的 `problem-domain/v1` 输出结构，在其上补齐必要能力。** 下方对照表的“当前第二步”列仍描述未提交的 [contracts.py](../server/shuxueshuo_server/problem_understanding/contracts.py)，仅用于说明需要撤掉的复杂性，不再作为继续扩充模型契约的起点。

### 1.0 以旧输出结构为基础，不回滚整个版本

保留一份整题抽取 IR，沿用 root/children，以及各层 source_text、entities、facts、goals。保留 right_angle、angle_sum、equal_length、length_relation 等专用基础关系的粒度，已有能力优先复用。

只增加或调整当前确有需求的部分：

- 补齐等角、角度比例、面积比、正切等简洁 fact／goal，以及必要的通用逻辑分组。
- 允许明确 unmatched、family_id=null；无匹配也保留完整 IR，不恢复旧版强制选择 family 的限制。
- 题内定义由 LLM 应用为各小问的基础关系，不添加按定义名字或特定组合硬编码的类型。
- 模型沿用原有点名和参数名，代码处理内部身份与作用域。
- 保留 OCR，但只提供简洁辅助视图。

撤回第二步要求模型编写的双树及关联、逐条来源覆盖、参数化定义模板、复杂 QuantityTerm 树和命名空间。代码内部如需要表达式节点或独立产物，可以转换生成，不反过来增加模型填写负担。

**这不是 git 回退，也不恢复旧模型配置。** DeepSeek 视觉接入及 enabled/low、按需独立视觉复核、修复预算、网络尝试上限、调用审计与恢复、表达式规范化和产品链已有修复继续保留。模型接口、校验器及转换器同步调整；不为缩小 schema 删除必要语义或放宽数学正确性检查。

18,599 字符是旧 provider schema 的比较基线，不是新版本必须达到的上限。新 schema 在必要扩展后重新测量，并通过现有五题和新增几何／unmatched 回归验证。当前只确认设计，未实施代码回滚、生产部署或历史数据清空。

### 1.1 首轮 LLM 只交付整题 Problem IR 与题型匹配结论

1. **产出整题 Problem IR**：沿用现有 `root/children` 层级，填写原文、原有对象名称、基础 facts 和 goals；遇到题内定义，将其应用到具体小问。保留缺图、不可辨内容和未定分支，不生成解题答案。
2. **给出题型匹配结论**：依据提供的 registry，匹配时填写已注册 family；没有覆盖本题要求的题型时明确 unmatched、family_id=null，并给出简短具体的能力缺口。不能为了选中某个题型删改 IR。

不要求模型分别编写一棵转录树和一棵领域树再建立连接，不引入顶层 parts 或另一套小问结构。转录和领域仍可作为内部独立产物，由代码从整题 IR 提取、转换和保存；这不意味着要让模型重复生成两套内容。

代码负责身份与修订、作用域解析、表达规范化、字段和数学一致性校验，以及匹配结果的验证和 Solver 转换。LLM 填了 family 并不等于代码已确认可求解；若 IR 错误，不能将其伪装为正常 unmatched。

这里描述的是首轮抽取职责。既有按需修复或独立看图复核仍按其用途处理，不因这次简化自动删除或新增调用。OCR 保留，模型只接收简洁辅助视图，见第 11 节；不改调用预算或复核触发策略。

名称说明：本文“整题 Problem IR”指模型的题目抽取 IR，沿用 problem-domain/v1 的 root/children 结构；代码中的 Solver ProblemIR 是投影后的另一种输入模型，不让 LLM 直接填写运行时数据。历史核查见 [输出 schema 变化历史](validation/problem-output-schema-history-20260915.md)。

模型响应中 IR 与匹配结果的外层字段仍按统一契约确定；下文只展示既有 root 层级及待简化的业务字段，不另造一套包裹结构。

以下表格的“现有”列使用函数式缩写展示实际节点结构，不是另一套待实现语法。例如 `angle(BDC)` 表示当前 `angle_measure` 节点及 degree 字段，`area(ACD)` 表示 `triangle_area` 节点及 unsigned 字段。完整 JSON 对照见第 3 节。

## 2. 简洁格式的共同约定

- 模型仅保留题面字面上的全题／小问／图景层级，把条件放在对应位置。第一问写 A，第二问仍写 A；不让模型生成命名空间、判断继承或跨问对象身份。后续代码负责解析作用域和生成内部唯一身份。
- 本文双点、三点简写仅适用于已声明的单个大写字母点名，例如 `AB`、`BAC`。多字符、下标或撇号点名必须用数组，例如 `["A1","B","C"]`；不能靠猜测拆分字符串。
- 同一类对象的名称只接受字符串简写或点名数组两种形式，不额外引入任意自然语言解析。
- 角为非定向内角，数值角度统一为度；三角形面积为无向面积。这些约定在契约中声明一次，模型无需逐节点重复。
- 精确数和参数算式用字符串，例如 `"2"`、`"1/2"`、`"sqrt(2)"`、`"k"`。代码用受控代数解析器解析；几何点名不因此成为代数变量。
- `ratio:["a","b"]` 与对象列表一一对应，表示比例约束，转换成交叉相乘等式。系数不能同时为零；单独出现几何比值所求时仍检查分母非零。对象和比例必须同时交换，不能丢掉方向。
- 等角、等长、平行、垂直的对象顺序可规范化；角的顶点、多边形顶点顺序、射线起点、除法分母不能任意交换。
- `in_terms_of:["k"]` 表示要求用 k 表示；省略则要求精确值。它不是已知答案。
- 简洁表达仍使用严格字段校验。不能识别或无法无歧义转换时保留原文并报告具体缺口，不猜条件、不假装已通过。

## 3. 角度、长度和面积

| 原题含义 | 当前第二步结构（缩写） | 建议模型输出 |
| --- | --- | --- |
| ∠BAC=∠DAC | `quantity_relation(=, angle(BAC), angle(DAC))` | `{"kind":"angle_equal","angles":["BAC","DAC"]}` |
| ∠BDC=2∠ABD | `quantity_relation(=, angle(BDC), multiply(number(2),angle(ABD)))` | `{"kind":"angle_ratio","angles":["BDC","ABD"],"ratio":["2","1"]}` |
| ∠ABC=45° | `quantity_relation(=, angle(ABC), angle_constant(45,degree))` | `{"kind":"angle_value","angle":"ABC","degrees":"45"}` |
| ∠ABC=90° | 同上，常量为 90° | `{"kind":"right_angle","angle":"ABC"}` |
| ∠CBE+∠ACO=45° | `quantity_relation(=, add(angle(CBE),angle(ACO)),angle_constant(45,degree))` | `{"kind":"angle_sum","angles":["CBE","ACO"],"degrees":"45"}` |
| AB=CD | `quantity_relation(=, length(AB),length(CD))` | `{"kind":"equal_length","segments":["AB","CD"]}` |
| BD=4CD | `quantity_relation(=, length(BD),multiply(number(4),length(CD)))` | `{"kind":"length_ratio","segments":["BD","CD"],"ratio":["4","1"]}` |
| AB=√2 | `quantity_relation(=,length(AB),measured_constant(sqrt(2),length))` | `{"kind":"length_value","segment":"AB","value":"sqrt(2)"}` |
| AB²=10 | 当前可表示为 `quantity_relation(=,multiply(length(AB),length(AB)),measured_constant(10,area))` | `{"kind":"squared_length_value","segment":"AB","value":"10"}` |
| S△ACD=S△ACB | `quantity_relation(=,area(ACD),area(ACB))` | `{"kind":"area_equal","triangles":["ACD","ACB"]}` |
| S△ACD=k·S△ACB | `quantity_relation(=,area(ACD),multiply(scalar(k),area(ACB)))` | `{"kind":"area_ratio","triangles":["ACD","ACB"],"ratio":["k","1"]}` |
| S△ABC=3 | `quantity_relation(=,area(ABC),measured_constant(3,area))` | `{"kind":"area_value","triangle":"ABC","value":"3"}` |

面积等值和面积比条件用于补齐表达能力，不能把本题“求面积比”擅自变成已知面积比。

当前角比例关系的实际节点结构（省略外层 Fact 的 ID、来源字段）：

```json
{
  "kind": "quantity_relation",
  "operator": "=",
  "left": {"kind":"angle_measure","angle":["B","D","C"],"unit":"degree"},
  "right": {
    "kind":"multiply",
    "terms":[
      {"kind":"number","value":"2"},
      {"kind":"angle_measure","angle":["A","B","D"],"unit":"degree"}
    ]
  }
}
```

建议模型只写：

```json
{"kind":"angle_ratio","angles":["BDC","ABD"],"ratio":["2","1"]}
```

转换器按关系类型构造角量、倍数及相等关系。内部左右两侧只是存储方式；相等关系的语义比较不受左右书写顺序影响。

## 4. 对象、位置与构造

| 原题含义 | 当前第二步结构（缩写） | 建议模型输出 |
| --- | --- | --- |
| 点 A | `Entity(id,point,label,role,source_unit_ids)` | 小问的 `entities` 中保留 `{"kind":"point","label":"A"}`，内部 ID 由代码生成，不填写逐实体来源引用 |
| A、B 为定点；C 为动点 | 各点逐个填写 role | 在对应 point 实体中保留 `role:"fixed"` 或 `role:"moving"`；没说明角色时不猜测，不新增另一套点列表 |
| 有序四边形 ABCD | `Entity(id,polygon,label,vertices,source_unit_ids)` | `entities` 中声明 polygon、原名及有序 vertices；不另设顶层 polygons 列表 |
| AC 为 ABCD 的对角线 | `diagonal(polygon_id,endpoints)` | `{"kind":"diagonal","polygon":"ABCD","segment":"AC"}` |
| AC 与 BD 相交于 O | `intersection(point,first,second,interior)` | `{"kind":"intersection","point":"O","segments":["AC","BD"],"interior":false}` |
| E 为 OB 中点 | `midpoint(point,segment)` | `{"kind":"midpoint","point":"E","segment":"OB"}` |
| BD 平分 AC | `diagonal_bisects(polygon,bisector,bisected)` | `{"kind":"diagonal_bisects","polygon":"ABCD","bisector":"BD","bisected":"AC"}` |
| AB∥CD | `parallel(first,second)` | `{"kind":"parallel","segments":["AB","CD"]}` |
| AB⊥BM | `perpendicular(first,second)` | `{"kind":"perpendicular","segments":["AB","BM"]}` |
| C 在射线 BM 上 | 声明 ray 实体，再 `point_on_ray(point,ray_id)` | `{"kind":"point_on_ray","point":"C","ray":"BM"}` |
| E 在线段 OB 上 | `point_on_segment(point,segment,interior)` | `{"kind":"point_on_segment","point":"E","segment":"OB","interior":false}` |
| ABCD 为平行四边形 | polygon 实体 + `parallelogram(polygon_id)` | `{"kind":"parallelogram","polygon":"ABCD"}` |
| ABCD 为正方形 | polygon 实体 + `square(polygon_id)` | `{"kind":"square","polygon":"ABCD"}` |

这里中点、平行、垂直原本就不复杂，主要减少实体引用包装。`diagonal_bisects` 保留明确的施动／被平分对象，不为省字段牺牲含义。

`interior:false` 表示未额外要求严格内部，端点允许；不表示必须在边界。只有原文明确时才能填 true；现有实际原图中的约束应逐条保留。不把相交自动加强成两条线段内部相交。

射线 BM 的 B 是起点，M 是方向点。代码可由这个显式表达创建射线对象；不能添加 C 在 B、M 之间的条件。涉及明确“直线”的关系使用相应 line 引用字段，不能统一误写为线段。

多边形顶点序由代码用于确定对角线：AECD 对应 AC、ED，不是 AC、BD。为表达相交关系可以使用普通辅助点名，代码解析其内部身份；不能将不同交点合并为原图已命名的 O。

“□ABCD”仍不确定时保留原文与缺口，不输出 parallelogram 或 square。

## 5. 所求表达

| 所求 | 当前第二步结构（缩写） | 建议模型输出 |
| --- | --- | --- |
| 求 k | `quantity_goal(scalar(k),exact_value)` | `{"kind":"find_value","target":"k"}` |
| 求 AB | `quantity_goal(length(AB),exact_value)` | `{"kind":"find_length","segment":"AB"}` |
| 求 ∠ABC | `quantity_goal(angle(ABC),exact_value)` | `{"kind":"find_angle","angle":"ABC"}` |
| 求 S△ABC | `quantity_goal(area(ABC),exact_value)` | `{"kind":"find_area","triangle":"ABC"}` |
| 求 S△ACD/S△ACB，用 k 表示 | `quantity_goal(divide(area(ACD),area(ACB)),expression_in(k))` | `{"kind":"find_area_ratio","triangles":["ACD","ACB"],"in_terms_of":["k"]}` |
| 求 AB/CD | `quantity_goal(divide(length(AB),length(CD)),exact_value)` | `{"kind":"find_length_ratio","segments":["AB","CD"]}` |
| 求 tan∠ACD | `quantity_goal(tan(angle(ACD)),exact_value)` | `{"kind":"find_tan","angle":"ACD"}` |
| 求点 P 坐标 | `coordinates_goal(point)` | `{"kind":"find_coordinates","point":"P"}` |
| 求抛物线解析式 | `equation_goal(curve)` | `{"kind":"find_equation","curve":"f"}` |
| 求 EG+FG 最小值 | `extremum_goal(add(length(EG),length(FG)),minimum,variables,…)` | `{"kind":"find_minimum","expression":"length(EG)+length(FG)","variables":["G"]}` |

比例所求中，第一项是分子、第二项是分母，不能排序。角度单位和面积约定由契约确定；代码照常登记非零分母及正切定义域义务，不把它们添成原题条件。

最值及复杂组合保留一个小型表达式入口，避免无限增加 find_* 类型。仅允许数字、参数、声明过的几何量函数和白名单运算；例如 `length(AB)`、`area(ABC)`、`angle(ABC)`、`tan(angle(ABC))`。多字符点名使用显式参数形式，例如 `angle(A1,B,C)`。必须编写有界解析器，不能直接 eval，也不能调用一个 LLM 来“猜着转换”。

这项是明确的实现成本：字符串较短不代表解析器已经存在。现有 scalar_algebra 只处理代数，不能未经扩展就解析几何函数。

## 6. 题内定义与逻辑分支

**最新决定：题内定义是基础关系的组合。保留定义原文，由 LLM 在每个使用该定义的小问中输出对应对象的通用基础 fact；代码不预置这道题的定义规则。**

撤回上一版 `diagonal_bisection_ratio`：它虽然换成英文操作名，仍把本题“某条对角线被平分、另一条按比例分段”的组合固化到编译器里。改名字不能消除这种硬编码。也不增加 `k_quad`、按题号匹配或按题内术语名字选择展开器。

### 6.1 职责重新划分

| 工作 | 负责方 |
| --- | --- |
| 从原图读取定义、参数限制和使用位置 | LLM |
| 理解“另一条”所指对象、将定义应用于具体四边形 | LLM |
| 结合本小问明确条件，输出中点、相交、长度比等基础 fact | LLM |
| 原文仍有选择时表达“或”，不擅自选方向 | LLM |
| 将简洁 fact 转成内部节点、解析点引用、生成内部 ID | 代码 |
| 对显式通用分支进行机械展开、检查类型与对象引用 | 代码 |
| 检查给出的对角线是否符合四边形顶点顺序 | 代码 |

此前“全部交给代码展开”的说法需要收窄：代码能展开已经明确表达的通用关系，不能在没有定义语义输入时自行知道一个新名词的数学含义。LLM 不编写 QuantityTerm 树，也不必为全题编写可执行定义模板；它需要完成题内定义的理解和应用。

### 6.2 第（2）问的局部 fact 示例

原题明确：ABCD 为 k 倍四边形，BD 平分 AC，∠BDC=2∠ABD，BD=4CD。定义对该小问的含义可直接落实为：

```json
{
  "facts":[
    {"kind":"scalar_constraint","symbol":"k","operator":">=","value":"1"},
    {"kind":"intersection","point":"X","segments":["AC","BD"],"interior":false},
    {"kind":"midpoint","point":"X","segment":"AC"},
    {
      "any_of":[
        [{"kind":"length_ratio","segments":["BX","XD"],"ratio":["k","1"]}],
        [{"kind":"length_ratio","segments":["XD","BX"],"ratio":["k","1"]}]
      ]
    },
    {"kind":"angle_ratio","angles":["BDC","ABD"],"ratio":["2","1"]},
    {"kind":"length_ratio","segments":["BD","CD"],"ratio":["4","1"]}
  ],
  "goals":[{"kind":"find_value","target":"k"}]
}
```

这是局部语义示例，省略原文与实体声明，字段形状供审查。X 是该小问为表达交点引入的构造点，不能伪称原图已标注 X；代码生成其内部唯一身份。`interior:false` 仍采用第 4 节“不额外要求严格内部”的含义，不声明交点在端点。

`any_of` 是通用的逻辑“或”，不是“k倍四边形”的专用节点。每个分支内 fact 同时成立。长度比例方向不能无依据确定，因此两种关系必须以“或”连接，不能都写成必成立条件。实现可对明确的通用无序比例简写作机械展开，但必须先定义其通用语义，不能根据本题名字猜方向。

本小问已指定 BD 平分 AC，不必再要求模型固定输出“任选哪条对角线”的四分支模板。若额外条件仍不足以消除某个分支，必须保留；不能把理解定义变成提前猜解题结论。

### 6.3 四个图景如何落地

| 图景 | 定义应用于 | 各自应保留的基础关系 |
| --- | --- | --- |
| 第（1）问图1 | AECD | 对角线 AC、ED 的交点；哪条被平分及另一条分段比为 k 的可能关系；局部 k≥1。题面未指定的角色和方向保留分支 |
| 第（1）问图2 | ABCD | BD 平分 AC 的中点／相交关系；BD 两段的长度比例为 k，未定方向保留；局部 k≥1 |
| 第（2）问 | ABCD | 与上例一致，并保留本问角倍数、BD=4CD、求 k |
| 第（3）问 | ABCD | BD 平分 AC；BD 两段比例为 2，未定方向保留；同时保留定点、动点、射线、垂直、等角及正切目标 |

图1原题已有 AC 与 BD 的交点 O、E 为 OB 中点；这不允许将 AECD 的 AC 与 ED 交点也命名为同一个 O。各小问点和参数独立，不能因同名字母跨问复用。缺图与“□ABCD”的歧义保留，不补平行四边形条件。

**不得默认添加 intersection.interior=true。** 对具体关系能确定的交点位置由明确条件或通用数学规则支持；不能为匹配旧金标而补入未经原文支持的限制。

### 6.4 原文、产物和泛化边界

- 定义原文保留在转录中，各小问保存定义应用后的 fact；删除二者之间逐条来源链接，不把展开内容伪装成原文逐字转录。
- 下游得到各小问的通用 fact 和必要的逻辑分组，不需要识别题内术语名字，也不以 definition_use 占位来代替已展开条件。
- 题内术语可保留在原文中，不要求额外名称引用或来源审查结构。内部参数化定义引擎不再是本步交付的必要条件；现有第二步定义模块仍是待调整代码，不宣称已按本方案实现。
- 换一个题内定义，只要其含义能用已有基础关系及通用逻辑表达，就由 LLM 输出不同的 fact 组合，不要求新增 schema 类型或专用展开器。
- 如果真正缺少基础关系，明确记录未表达原文和能力缺口；不能把任意中文字符串当作代码已经理解的条件。
- 用人工审核夹具和语义对照验证定义应用，不再用来源 ID 或覆盖表充当完整性检查。

### 6.5 Prompt 简洁说明与独立 few-shot

已确认在后续提示词中加入一段简短规则及一个独立示例。以下为拟采用内容，本次仅更新文档，尚未写入运行提示词。

**规则：**

> 题目可能临时定义一个概念或运算。以本题给出的定义为准，不按名称套用已有含义。将定义应用到各小问的具体对象，输出对应的通用基础 fact，并保留定义原文。不得为题内术语新造 fact 类型；定义中未确定的选择或方向须保留，不能自行选定。此过程只展开定义，不求解答案。

**独立示例题面：**

> 若三角形某顶点相邻的两边相等，则称它为该顶点的“等邻三角形”。已知 ABC 为 A 点的等邻三角形，DEF 为 E 点的等邻三角形。

**对应基础 fact：**

```json
[
  {"kind":"equal_length","segments":["AB","AC"]},
  {"kind":"equal_length","segments":["ED","EF"]}
]
```

示例仅展示定义应用后的 fact 片段，不另设首包格式；实际首包仅需保留原文层级、原有对象名称及基础关系，不填写内部身份或逐条来源关联。它说明同一题内定义应用于不同顶点时，需要替换对应对象；无需创建“等邻三角形”类型、编写表达式树或推导解题结论。

提示词与测试边界：

- 初版只放这一个独立编写的示例，不把“k倍四边形”的定义展开或五题金标放入通用 prompt。
- 分支保留先由规则说明；只有独立测试显示模型仍会擅自选择分支，才补充一个含“或”的短示例，不预先堆积样例。
- 示例在实现时须通过实际简洁 schema 及转换器校验，不能另行维护与解析器不一致的示例格式。
- 独立测试覆盖定义改名、同名但定义改变、作用顶点改变、多小问局部对象及未定分支保留；测试题不直接复用这个示例作为泛化通过证据。
- 不新增模型调用或扩大调用预算；真实调用另按既定验收流程执行。

## 7. 保留五题能力：坐标、曲线和最值条件

几何简化不能让已通过的二次函数题退化。以下表达保留为并列能力，不要求每道题填写全部字段。

| 能力 | 当前第二步格式（缩写） | 建议模型输出 |
| --- | --- | --- |
| 点坐标 | `coordinates(point,x:Q,y:Q)` | `{"kind":"coordinates","point":"P","value":["m","m^2-1"]}` |
| 原点 | `origin(point)` | `{"kind":"origin","point":"O"}`，保留 |
| 平移 | `translation(point,original,vector:Q[])` | `{"kind":"translation","point":"Q","original":"P","vector":["1","-2"]}` |
| 曲线方程 | `curve_equation(curve,expression:Q,independent,dependent)` | `{"kind":"curve_equation","curve":"f","expression":"a*x^2+b*x+c","independent":"x","dependent":"y"}` |
| 点在曲线上 | `point_on_curve(point,curve)` | 原样保留 |
| 曲线上给定横坐标的点 | `curve_at_x(point,curve,x:Q)` | `{"kind":"curve_at_x","point":"P","curve":"f","x":"m"}` |
| 顶点或坐标轴交点 | `curve_landmark(point,curve,landmark,side,exclude_point)` | 保留专用类型；没有 side/exclude_point 时不要求填 null，有指定时必须保留 |
| 点在坐标轴上 | `point_on_axis(point,axis,curve)` | 保留，curve 只在需要绑定对称轴时提供 |
| 参数限制 k≥1 | `quantity_relation(>=,scalar(k),number(1))` | `{"kind":"scalar_constraint","symbol":"k","operator":">=","value":"1"}` |
| “最小值等于给定值”是已知条件 | `extremum_constraint(direction,expression:Q,variables,value:Q)` | 保留该 fact 类型，将 expression/value 换成受控简洁表达；不能转换成所求 |

曲线声明同时区分自变量、因变量与题内参数；代码可以从表达式提取出现的符号，但不能凭出现顺序猜数学角色。最值变量引用也需要明确类型；例中 G 为动点，并非普通代数参数。

## 8. 字面层级、代码作用域与删除来源关联

### 8.1 模型只按题面层级填写

模型不承担编程意义上的作用域管理，只按原文的全题、第（1）问、第（2）问、图1／图2等字面位置放入原文、条件和所求。无需把同名 A 改成 p1_A、p2_A，也无需填写全局唯一 ID、父域引用、继承列表或跨小问实体绑定。

撤回上一版顶层 `parts` 示例。沿用现有整题 IR 的 `root`，小问使用其 `children`；层内继续使用 `source_text/entities/facts/goals`，不再另设 `points/items/text` 来替代已有容器字段。

以下展示整题 IR 的 root 内容，包含两个小问的原文、实体、条件和所求；匹配结果、版本及服务端身份元数据不在这个层级示例中重复展示。简洁 fact 与实体字段仍待 schema 实现，不宣称可直接通过旧 v1 校验：

```json
{
  "root": {
    "label": "三角形题",
    "source_text": [
      "分别回答下列两个小问。"
    ],
    "entities": [],
    "facts": [],
    "goals": [],
    "children": [
      {
        "label": "（1）",
        "source_text": [
          "在三角形ABC中，AB=AC，AB=3，求AC的长。"
        ],
        "entities": [
          {
            "kind": "point",
            "label": "A"
          },
          {
            "kind": "point",
            "label": "B"
          },
          {
            "kind": "point",
            "label": "C"
          }
        ],
        "facts": [
          {
            "kind": "equal_length",
            "segments": [
              "AB",
              "AC"
            ]
          },
          {
            "kind": "length_value",
            "segment": "AB",
            "value": "3"
          }
        ],
        "goals": [
          {
            "kind": "find_length",
            "segment": "AC"
          }
        ],
        "children": []
      },
      {
        "label": "（2）",
        "source_text": [
          "在三角形ABC中，∠BAC=∠BCA，∠ABC=40°，求∠BAC的度数。"
        ],
        "entities": [
          {
            "kind": "point",
            "label": "A"
          },
          {
            "kind": "point",
            "label": "B"
          },
          {
            "kind": "point",
            "label": "C"
          }
        ],
        "facts": [
          {
            "kind": "angle_equal",
            "angles": [
              "BAC",
              "BCA"
            ]
          },
          {
            "kind": "angle_value",
            "angle": "ABC",
            "degrees": "40"
          }
        ],
        "goals": [
          {
            "kind": "find_angle",
            "angle": "BAC"
          }
        ],
        "children": []
      }
    ]
  }
}
```

两个小问都使用原名 A、B、C，实体 label 为原题名称；没有要求模型生成内部 ID。示例没有输出答案。全题公共条件仍放在 root，小问条件放在相应 child；不要求模型为了内部可见性把条件上移、下移或另建共享层。

代码按字面容器解析局部名称、全题条件的可见性及局部重定义；显式“沿用第（1）问”保留在原文中，由后续处理判断。不得仅因为同名就合并不同图景，也不能把所有小问一律完全隔离而丢掉实际共享条件。现有规则无法确定时记录具体歧义，不声称程序能凭名字猜出任意数学语义。

后续定向修复所需的稳定内部 ID 和精确修订绑定由代码维护，不作为首轮模型的命名任务。

可加入的简短提示：

> 按题面原有层级填写原文、条件和所求，沿用原来的点名与参数名；不同小问允许同名。不要创建带小问前缀的名称、内部 ID、继承关系或来源引用。

### 8.2 定义形参与私有交点不再是模型契约

“定义形参”是上一版模板里的占位对象，例如 P 表示任意四边形、r 表示待传入的比例；应用时再把 P 换成 AECD、r 换成 k 或 2。现在直接在各小问输出具体对象的基础 fact，不需要模型编写这套模板和参数绑定。

“实例私有交点”是模板每应用一次就生成一个不同内部身份的交点，防止不同四边形的交点被误合并。这种内部身份由代码管理。若基础 fact 需要辅助交点，可以在所在字面小问中普通地写 `intersection(point="X",…)`；不要求填写 witness、instance_id、全局唯一名称或实例来源。X 必须具有明确的构造关系，不能伪称原图已标注 X。

实际几何关系仍须正确：AECD 的对角线是 AC、ED，其交点不应无依据地复用 AC、BD 的交点 O。取消模型的内部身份管理，不是允许改变点的数学含义。

### 8.3 删除逐条来源关联

删除“每条 fact/goal/entity 指向原题某一句话”的机制，不转交代码继续自动生成：

- 模型契约不再包含 source_unit_ids、source_unit_refs 或原文—fact 逐条映射。
- 不强制为每句原文分配稳定 ID，不维护来源反向索引或覆盖表，不以这类引用缺失阻断采用。
- 不把 fact 嵌在逐句原文条目下，以隐式对应替代已删除的显式映射；在既有 root/children 各层分别保存 source_text、facts、goals 即可。
- 保留原图、完整转录、原始模型返回、调用审计和必要的修订绑定。这些是整次输入输出记录，不是逐条题设来源链接。
- 缺图、文字不清与印刷／手写等已有观察信息仍可以保留；它们不能要求模型逐条关联到领域 fact。
- 转录遗漏、定义误用和条件丢失通过题面／领域语义复核及人工金标对照测试检查，不再承诺来源覆盖表提供的形式保证。

本节替代第 8 节此前“两棵树连接、原文条目内嵌 fact、自动生成来源索引”的建议。运行 schema 仍要求旧字段，实施时必须一起调整 schema、解析器、验证器和测试，不能只删除提示词让模型必然校验失败。

## 9. Schema 能缩减什么

可以缩减模型侧 schema，但不能只凭 JSON 示例变短宣称 schema 一定同比变小。

| 内容 | 建议处理 | 影响 |
| --- | --- | --- |
| 模型输出递归 QuantityTerm | 常用关系使用扁平 fact；复杂量用受控表达式 | 大幅减少每条业务 JSON 的节点和包装 |
| degree、unsigned、number/scalar 包装 | 固定约定写一次；代码按 fact 类型生成 | 不要求模型反复填写常量字段 |
| 参数化定义模板、polygon_vertex、definition_use | LLM 直接输出各小问通用 fact；代码解析引用和机械转换 | 移除模型编写通用模板的负担；实际输出大小需计入小问间必要重复 |
| 命名空间、Fact/Goal 内部 ID、语义 scope 管理 | 沿用 IR root/children 及原名，代码处理内部身份 | 模型不编写前缀、继承和跨问身份绑定 |
| source_unit_ids、逐句 ID、来源覆盖表 | 从设计中删除，不转交代码重建 | 减少首包字段及形式化关联检查 |
| problem_id、原图哈希、修订哈希 | 服务端请求上下文绑定并生成 | 无需模型复制；审计仍保存 |
| 义务、内部转换记录、采用状态 | 只由代码计算 | 不放入可填写模型 schema |
| 原有点名、比例方向、题面字面层级、缺图等不确定信息 | 必须保留 | 保留题意；不要求逐条来源链接或模型设计作用域 |
| 专用 fact 类型增加 | 共用 GeometryRef、ExactExpression 定义，统一注册生成 | 分支数可能增加，必须实测 schema 总大小 |
| 匹配结果 | 继续独立区分 matched/unmatched，不因省字段强选 family | 本文不擅自改变匹配调用时机 |

建议维护一份“简洁操作名 → 字段 → 转换器 → 语义约束”的注册定义，由此生成模型 schema、说明和合法示例。内部结构 schema 单独服务于程序校验，不再全部塞给模型。每个操作都要有转换测试，防止两个契约漂移。

**不承诺压缩百分比。** 完整简洁 schema 尚未实现。此前 lossless $defs 压缩后，作者 schema 仍约 21,389 个紧凑 JSON 字符；真正请求还含观察、示例与 registry。这次改变字段职责与表达粒度，预计能够减少请求及返回，但必须分别记录以下指标：

1. 完整模型 schema、提示词、示例的字符数；同一种 tokenizer 下的 token 数（若可取得）。
2. 同一金标用两种格式序列化后的大小与节点数。
3. 真实请求 input/reasoning/final tokens、耗时、截断率与通过率。

## 10. 实施前后的验收约束

1. 角相等可交换对象；角比例同时交换对象和比例仍等价，仅交换对象不等价。
2. 中点、平行、垂直、射线的简洁表达转换到正确节点；多字符点名无歧义解析。
3. 角度值、面积值、长度值各自类型明确，不能把单位错误当成简写容错。
4. 面积比所求保留分子/分母与指定参数；正切目标不再伪装为求 k。
5. 各小问基础 fact 完整表达定义及本问条件，未定分支保留；AECD 使用自身对角线和局部交点，不能无依据添加 interior=true。定义改名不影响结果，同名但定义内容变化必须改变对应 fact；增加不同组合的题内定义测试，确保无需新增专用类型或按名分派。
6. 模型在不同小问沿用同名点，无前缀和内部 ID；代码正确处理局部身份、公共条件和显式沿用关系。不要求逐条来源引用或覆盖表，缺少这些字段不构成校验错误。
7. 未知算子、歧义点名、非法表达式、无效引用明确报错；不调用额外 LLM 猜转换。
8. 本题和现有五题简洁夹具转换后与原金标语义一致；不能通过删条件降低失败率。
9. 首轮只产出完整 Problem IR 与匹配结论，沿用 root/children，不生成顶层 parts 或重复的转录／领域树；matched/unmatched 都保留完整 IR，缺失类型时不强制选 family。
10. 先通过离线转换测试，再另行执行有固定调用预算的真实对照。本文没有启动付费调用。

建议审查顺序：先确认第 3～5 节基本 fact/goal，再审查第 6 节定义应用后的基础 fact 与分支。第 8 节字面层级与来源关联删除、第 11 节保留 OCR 并简化使用按最新决定实施；本次不改变模型调用拆分及预算。

## 11. 保留 OCR，简化模型侧辅助输入

已确认：本轮不删除 OCR 服务或观察阶段，只精简传给模型的信息。完整原图继续是语义依据，原始 OCR、布局与诊断仍在内部留存；不能因原始字段不再出现在 prompt 中而修改原始产物。

首轮请求由完整题图、简洁输出 schema、题型目录、简短说明／独立示例和可选的简洁 OCR 辅助组成，不再直接传整份 observation JSON。已有必要 zoom 可继续提供，不固定增加模型调用。

### 11.1 各类数据去留

| 原始类别 | 给模型的内容 | 留在内部的内容 |
| --- | --- | --- |
| text_spans | 按页序和原有行序组织的 OCR 文字，仅作候选辅助 | 行 ID、block_id、逐行多边形、置信度、reading_order 数字 |
| formulas | 正文未覆盖的有用公式候选；冲突或模糊时标为待看图核查 | 重复候选、供应商记录、source_observation_ids、原始状态与完整关联 |
| layout_blocks | 首轮不传完整列表；仅在需要定位疑点时给必要的局部位置或 zoom | 版面块、类别、provider_label、全部坐标及检测分数 |
| ink_origins | 存在批注干扰时给简短提示，分类不是原图语义的最终判断 | 全部笔迹检测记录、关联 ID |
| occlusions | 有遮挡时给简短说明及必要位置／局部图 | 完整遮挡记录 |
| issues | 仅将真正需要看图核查的内容转成中性短提示 | issue_id、内部错误码、blocking、retryable、诊断关联图 |
| pages | 多页保留页序；与具体疑点相关时保留页码 | 宽高、旋转处理记录及其他技术元数据 |

不向模型发送 observation_id、source_observation_ids、逐条置信度、空类别数组或“请理解内部错误码”的任务。原有文字分行应保留，不将分式上下两行仅凭阅读顺序强行拼成某个已确认算式。

### 11.2 筛选规则与边界

- 删除重复的包装字段，不按 printed/unknown、是否属于已检测版面块来删除文字。缺少 block 的未知子问、分母或图示文字仍进入文字候选或核查提示。
- 文字识别与公式识别冲突时，保留必要的不同候选并标明差异，不能用其中一份自动覆盖另一份；精确重复可由代码去重。无法可靠判断是否重复的内容不能仅凭字符串相似度删除。
- 不因公式状态 unresolved 或来源 unknown 就自动丢弃；也不将其当成题设事实。有效的补充信息保留为候选，最终由模型看图决定。
- 不逐条传 confidence。当前公式适配器在供应商缺少分数时使用 0.5，不能把默认值描述为正确概率或作为保留／删除条件。
- no_question_label_detected 表示程序没检测到题号，不表示原图没有完整题目；formula_origin_not_printed 也不表示公式不存在。此类状态不能作为权威结论喂给模型。
- 若有手写／混合的识别候选，保留其不确定性质，不能拼进没有区分的“印刷题干”。必要时用短提示提醒核对，完整标签和记录保存在内部。
- 不推断模型图像看不见的条件，不把简化 OCR 输入变成改写题意、自动补全文字或求解。

例如本次记录中正文为 BD=4CD，某公式候选为 BD=4C,；可以提示“两种识别结果不同，请按原图确认”，而不是发送整串内部错误码。正文为 tan∠ACD 时，公式识别额外出现的反斜杠 bar{x} 不能自动成为条件。实际提示只在存在对应差异时生成，不将这些样本内容固化为通用 prompt。

### 11.3 实施与测试

1. 单独生成模型辅助视图，保持原始观察产物及哈希不变；删除的是请求中的冗余数据，不是内部诊断能力。
2. 测试覆盖未知且没有 layout block 的文字、正文／公式冲突、分式行序、多页、手写／混合、遮挡和无疑点输入。没有疑点时不添加空提示或内部诊断。
3. 记录 schema、OCR 文字、公式候选、疑点提示、示例和整段请求的大小。当前实验 observation_auxiliary 为 8,926 字符，其中 14 条文字正文合计 383 字符；不是承诺新辅助输入必然只有 383 字符。
4. OCR 简化不改变按需视觉复核触发策略；内部仍使用完整观察判断是否触发。之后是否做纯图对照另行决定，本轮先保留 OCR。

运行中的 observation_view、prompt_payload 及测试仍待按本节修改；本次文档更新不代表请求已精简。
