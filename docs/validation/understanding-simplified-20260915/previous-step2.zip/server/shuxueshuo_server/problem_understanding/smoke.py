"""One semantic call only. A failed gate is retained; never auto-repair/review/retry a run."""

import json
import os
from hashlib import sha256
from pathlib import Path
from time import perf_counter

from .authoring import AUTHORING_POLICY, observation_view
from .comparison import compare
from .contracts import CONTRACTS, schema
from .identity import revision
from .prompt import SYSTEM, prompt_payload
from .service import parse_candidate


def build_request(fixture, store, registry):
    from PIL import Image

    from shuxueshuo_server.solver.extraction.multimodal_evidence import (
        MultimodalEvidencePack,
        MultimodalImageInput,
    )
    from shuxueshuo_server.solver.extraction.multimodal_provider import (
        MultimodalExtractionPrompt,
        MultimodalProviderImage,
        MultimodalProviderRequest,
    )

    content = (fixture / "source.png").read_bytes()
    digest = sha256(content).hexdigest()
    provenance = json.loads((fixture / "provenance.json").read_text())
    for row in provenance["files"]:
        if (
            sha256((fixture / row["file"]).read_bytes()).hexdigest()
            != row["fixture_sha256"]
        ):
            raise ValueError("fixture hash mismatch: " + row["file"])
    if digest != provenance["image_sha256"]:
        raise ValueError("source hash mismatch")
    observation = json.loads((fixture / "observation.json").read_text())
    image = store.put_bytes(
        kind="understanding_primary",
        content=content,
        media_type="image/png",
        suffix=".png",
    )
    width, height = Image.open(fixture / "source.png").size
    if (width, height) != (
        observation["pages"][0]["width"],
        observation["pages"][0]["height"],
    ):
        raise ValueError("observation image dimensions mismatch")
    pack = MultimodalEvidencePack(
        schema_version="multimodal-evidence-pack/v1",
        evidence_pack_id="step2",
        base_context_id="step2",
        source_id="step2",
        source_revision_hash=digest,
        selection_id="whole-image",
        observation_hash=observation["observation_hash"],
        images=(
            MultimodalImageInput("primary", "page-1", "primary", image, width, height),
        ),
        printed_text=(),
        recognized_formulas=(),
        unresolved_items=(),
        region_index=(),
    )
    # Save complete evidence and the reversible alias map; only the semantic view goes to the model.
    _, aliases = observation_view(observation)
    observation_artifact = store.put_json(
        kind="understanding_observation_original", payload=observation
    )
    aliases_artifact = store.put_json(
        kind="understanding_observation_aliases", payload=aliases
    )
    store.put_json(
        kind="understanding_observation_view_manifest",
        payload={
            "schema_version": "problem-observation-view-audit/v1",
            "source_sha256": digest,
            "original": observation_artifact.to_payload(),
            "aliases": aliases_artifact.to_payload(),
            "view_sha256": revision(observation_view(observation)[0]),
        },
    )
    payload = prompt_payload(
        problem_id="k-quad",
        source_sha256=digest,
        registry=registry,
        observation=observation,
    )
    request = MultimodalProviderRequest(
        evidence_pack=pack,
        prompt=MultimodalExtractionPrompt(
            SYSTEM,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            "请从完整图片输出题意 JSON。",
        ),
        images=(
            MultimodalProviderImage(
                "primary", "page-1", "primary", image, content, width, height
            ),
        ),
        contract_version="problem-understanding/v1",
        contract_schema=payload["response_schema"],
        response_format={"type": "json_object"},
    )
    return request


def run(fixture, output, provider, registry):
    from shuxueshuo_server.solver.extraction.artifacts import ExtractionArtifactStore

    output.mkdir(parents=True, exist_ok=True)
    # Exclusive durable reservation, including crashes: resuming this experiment never pays again.
    marker = output / "semantic-call-reserved.json"
    store = ExtractionArtifactStore(output / "artifacts")
    request = provider.prepare_request(build_request(fixture, store, registry))
    expected = json.loads((fixture / "gold.json").read_text())
    frozen = {
        "authoring_policy": AUTHORING_POLICY,
        "authoring_schema_hash": revision(request.contract_schema),
        "system_prompt_hash": sha256(SYSTEM.encode()).hexdigest(),
        "contracts": {c: revision(schema(c)) for c in CONTRACTS},
        "request_hash": revision(request.redacted_payload()),
        "gold_sha256": sha256((fixture / "gold.json").read_bytes()).hexdigest(),
        "image_sha256": request.images[0].artifact.sha256,
        "semantic_budget": 1,
        "network_budget": 2,
        "sdk_retries": 0,
        "registry_snapshot": revision(registry),
    }
    with marker.open("x") as f:
        json.dump(frozen, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())

    def save(name, x):
        (output / name).write_text(json.dumps(x, ensure_ascii=False, indent=2) + "\n")

    save("request.json", request.redacted_payload())
    save("frozen.json", frozen)
    started = perf_counter()
    summary = {
        "passed": False,
        "candidate_only": True,
        "source_reviewed": False,
        "solver_ready": False,
        "semantic_calls": 1,
        "network_attempts": 0,
    }
    try:
        response = provider.complete(request)
        (output / "raw-response.txt").write_text(response.text)
        save("provider-response.json", response.raw_payload)
        save("call.json", response.metadata_payload())
        summary["network_attempts"] = len(response.provider_attempts)
        parsed = parse_candidate(
            response.text,
            problem_id="k-quad",
            source_sha256=request.images[0].artifact.sha256,
            registry_snapshot=revision(registry),
            registered_families=[f["family_id"] for f in registry],
            store=store,
        )
        save("parsed.json", parsed)
        diff = {"ok": False, "reason": "invalid domain"}
        if parsed.get("contract_valid"):
            actual = parsed["objects"]
            diff = compare(expected["domain"], actual["domain"])
            expected_gaps = sorted(
                g["reason"] for g in expected["transcription"]["source_gaps"]
            )
            actual_gaps = sorted(
                g["reason"] for g in actual["transcription"]["source_gaps"]
            )
            diff["source_gap_types_match"] = actual_gaps == expected_gaps
            diff["unmatched"] = actual["match"]["status"] == "unmatched"
            summary["passed"] = (
                diff["ok"] and diff["source_gap_types_match"] and diff["unmatched"]
            )
        save("diff.json", diff)
        if (
            response.finish_reason != "stop"
            or not 1 <= summary["network_attempts"] <= 2
        ):
            summary["passed"] = False
            summary["error"] = "truncated/invalid finish reason or network budget"
        summary["contract_valid"] = parsed.get("contract_valid", False)
    except Exception as exc:  # noqa: BLE001 - durably record all isolated experiment failures
        # Do not stringify authenticated SDK/client objects or request headers.
        summary["error_type"] = type(exc).__name__
        summary["error_code"] = getattr(exc, "code", None)
        attempts = getattr(provider, "last_provider_attempts", ())
        summary["network_attempts"] = len(attempts)
        save(
            "failed-attempts.json",
            [{k: v for k, v in a.items() if k != "error_message"} for a in attempts],
        )
    summary["elapsed_seconds"] = round(perf_counter() - started, 3)
    save("summary.json", summary)
    return summary


def main():
    import argparse

    from dotenv import load_dotenv

    from shuxueshuo_server.solver.extraction.multimodal_provider import (
        DeepSeekMultimodalExtractionProvider,
        problem_domain_family_catalog,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if os.getenv("RUN_LLM_INTEGRATION") != "1":
        raise SystemExit("RUN_LLM_INTEGRATION=1 required; no skipped acceptance")
    root = Path(__file__).resolve().parents[3]
    load_dotenv(root / "server/.env")
    load_dotenv(root / ".env")
    key = os.getenv("DEEPSEEK_API_KEY")
    if not key:
        raise SystemExit("missing DEEPSEEK_API_KEY; live gate NOT executed")
    client = DeepSeekMultimodalExtractionProvider(
        api_key=key,
        base_url="https://api.deepseek.com",
        model="deepseek-flash",
        request_timeout=300,
        max_output_tokens=16384,
    )
    result = run(
        root / "server/tests/solver/fixtures/understanding-v2/k-quad",
        args.output,
        client,
        list(problem_domain_family_catalog()),
    )
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
