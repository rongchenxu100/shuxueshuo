"""Lossless schema factoring and a semantic observation view for model authors."""

from collections import Counter
from copy import deepcopy

from .identity import encoded

AUTHORING_POLICY = "problem-understanding-authoring/v2"
AUTO_COVERAGE = "from_source_unit_ids"


def compact_schema(source):
    """Factor repeated schemas into $defs without dropping validation constraints."""
    counts = Counter()
    originals = {}

    def collect(node):
        if isinstance(node, dict):
            if (
                any(k in node for k in ("type", "oneOf", "anyOf"))
                and len(encoded(node)) >= 100
            ):
                key = encoded(node)
                counts[key] += 1
                originals[key] = node
            for value in node.values():
                collect(value)
        elif isinstance(node, list):
            for value in node:
                collect(value)

    collect(source)
    keys = sorted(key for key, count in counts.items() if count > 1)
    # Generated names cannot shadow a definition in the authoritative schema.
    prefix = "shared"
    while any(name.startswith(prefix) for name in source.get("$defs", {})):
        prefix += "_"
    names = {key: f"{prefix}{i}" for i, key in enumerate(keys)}

    def factor(node, own_key=None):
        if isinstance(node, dict):
            key = encoded(node)
            if key in names and key != own_key:
                return {"$ref": "#/$defs/" + names[key]}
            return {k: factor(v) for k, v in node.items()}
        if isinstance(node, list):
            return [factor(v) for v in node]
        return node

    result = factor(source)
    result.setdefault("$defs", {}).update(
        {names[key]: factor(originals[key], key) for key in keys}
    )
    return result


_AUDIT_FIELDS = {
    "provider_id",
    "source_artifact_id",
    "crop_artifact_id",
    "formula_request_id",
    "mask_artifact_id",
    "source_revision_hash",
    "dependency_hash",
    "locator",
}
_GROUPS = (
    "layout_blocks",
    "text_spans",
    "formulas",
    "ink_origins",
    "occlusions",
    "issues",
)


def observation_view(observation):
    """Keep every semantic record, including unknown/mixed/occluded observations.

    Short aliases replace opaque identifiers only in this derived view. The full
    source observation and alias map remain separate audit artifacts, unchanged.
    """
    aliases = {}
    for group in _GROUPS:
        for row in observation.get(group, []):
            for key in ("observation_id", "issue_id"):
                if key in row and row[key] not in aliases:
                    aliases[row[key]] = f"o{len(aliases) + 1}"

    def clean(value):
        if isinstance(value, dict):
            return {k: clean(v) for k, v in value.items() if k not in _AUDIT_FIELDS}
        if isinstance(value, list):
            return [clean(v) for v in value]
        if isinstance(value, str):
            return aliases.get(value, value)
        return value

    result = {
        "schema_version": "problem-observation-author-view/v1",
        "coordinate_format": "polygon=[x,y] points normalized to [0,1]; output bbox=[x0,y0,x1,y1]",
        "pages": [
            {
                k: deepcopy(row[k])
                for k in ("page_id", "width", "height", "orientation_degrees")
                if k in row
            }
            for row in observation.get("pages", [])
        ],
        **{group: clean(observation.get(group, [])) for group in _GROUPS},
    }
    return result, {short: original for original, short in aliases.items()}


def coverage_from_links(domain):
    """Invert explicit author associations. Never infer a missing semantic link."""
    rows = {}

    def record(unit):
        if not isinstance(unit, dict) or not isinstance(unit.get("id"), str):
            return
        for sid in (
            unit.get("source_unit_ids", [])
            if isinstance(unit.get("source_unit_ids"), list)
            else []
        ):
            if not isinstance(sid, str):
                continue  # The untouched unit fails canonical schema validation.
            rows.setdefault(
                sid, {"source_unit_id": sid, "domain_unit_ids": [], "gap_id": None}
            )["domain_unit_ids"].append(unit["id"])

    def visit(scope):
        if not isinstance(scope, dict):
            return
        for kind in ("entities", "facts", "goals"):
            for unit in (
                scope.get(kind, []) if isinstance(scope.get(kind), list) else []
            ):
                record(unit)
        for child in (
            scope.get("children", []) if isinstance(scope.get("children"), list) else []
        ):
            visit(child)

    visit(domain.get("root"))
    for definition in (
        domain.get("definitions", [])
        if isinstance(domain.get("definitions"), list)
        else []
    ):
        record(definition)
    for gap in domain.get("gaps", []) if isinstance(domain.get("gaps"), list) else []:
        if not isinstance(gap, dict) or not isinstance(gap.get("source_unit_id"), str):
            continue
        sid = gap["source_unit_id"]
        if sid in rows:
            # Preserve graph/gap conflicts for the canonical validator to reject.
            if rows[sid]["gap_id"] is not None:
                rows[sid]["domain_unit_ids"].append("invalid_duplicate_gap")
            rows[sid]["gap_id"] = gap.get("id")
        else:
            rows[sid] = {
                "source_unit_id": sid,
                "domain_unit_ids": [],
                "gap_id": gap.get("id"),
            }
    return list(rows.values())


def normalize_definition_arguments(domain):
    """Resolve scalar ID shorthand using declared parameter types, never labels.

    The author schema permits ID or QuantityTerm arguments. Canonical validation
    still checks the ID's actual entity type and lexical scope after expansion.
    """
    definitions = domain.get("definitions", [])
    if not isinstance(definitions, list):
        return
    formals = {}
    for definition in definitions:
        if not isinstance(definition, dict) or not isinstance(
            definition.get("id"), str
        ):
            continue
        parameters = definition.get("parameters", [])
        if isinstance(parameters, list):
            formals[definition["id"]] = {
                p["id"]: p.get("kind")
                for p in parameters
                if isinstance(p, dict) and isinstance(p.get("id"), str)
            }

    def visit(value):
        if isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, dict):
            if value.get("kind") == "definition_use" and isinstance(
                value.get("definition_ref"), str
            ):
                params = formals.get(value["definition_ref"], {})
                args = value.get("arguments")
                if isinstance(args, dict):
                    for name, argument in list(args.items()):
                        if params.get(name) == "scalar" and isinstance(argument, str):
                            args[name] = {"kind": "scalar", "symbol_ref": argument}
            for child in value.values():
                visit(child)

    visit(domain)
