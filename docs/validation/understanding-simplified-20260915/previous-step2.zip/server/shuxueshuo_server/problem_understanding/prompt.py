"""The prompt consumes generated schemas and schema-validated authored examples."""

from .authoring import AUTHORING_POLICY, AUTO_COVERAGE, compact_schema, observation_view
from .contracts import parse
from .identity import revision
from .service import response_schema

SYSTEM = """你从完整原题图片提取可独立保存的题意，只输出一个严格 JSON 对象，不输出解法或答案。
图片是题意依据，OCR 是辅助。区分印刷条件与批注；缺图、不可辨符号保留为 source_gaps，不能猜成常见几何条件。
分层转录原文，条件、定义、所求分别有稳定 ID。每一个可读条件及所求都要编码并覆盖，不能用 partial 省略本契约支持的内容。
各独立图景分别使用局部实体和参数；有明确共享的上层条件才继承，不允许跨 sibling 引用。全题单元 ID 唯一。按原文顺序命名 part p1,p2,…；各图景实体统一使用 part ID 前缀，如 p1_U、p2_U，同名标签 U 不等于同一实体；按该规则直接输出，不必自行设计命名体系。实体身份也引用来源单元。
领域图与题型无关。matched、unmatched 都必须返回完整非空 domain。只按给定 registry 快照判断匹配；无适合 family 就明确 unmatched，family_id=null，给出引用具体来源和图单元的能力缺口。
定义用有类型形参、局部 witness、all/any 表达所有可能分支；未知比值方向和被平分对象不能随意选择。定义实例通过 definition_use 传参，由代码独立展开。形参选择顶点用 polygon_vertex，普通 polygon.vertices 使用已声明点 ID。
角度是三点内角、单位 degree；面积 unsigned。正切仅接收角度；几何量用 QuantityTerm，不伪装成 scalar_algebra 字符串。精确根式用 sqrt、有理数用分数。字母表达式 refs 必须是合法标识符且仅包含可见 scalar，不能使用点或几何量的名字。
量纲严格：number 和 scalar 无量纲，角常量用 angle_constant，已给定数值长度或面积用 measured_constant 并显式指定单位；倍数用 multiply。保留有序多边形的顶点顺序。
首包领域引用 response.transcription，匹配引用 response.transcription 与 response.domain，服务端解析后封存精确哈希；不要计算、猜写内容哈希。problem_id、source_sha256、registry_snapshot 必须逐字复制请求身份。
只输出 source_unit_ids 这一份语义关联；domain.coverage 固定填 "from_source_unit_ids"，代码反向生成覆盖表。不能把 Scope 当作覆盖单元。要求单元必须引用对应 Goal；事实/实体不能冒充所求。
Part 是转录树，Scope.part_ref 绑定对应 Part；实体/事实/目标的来源单元必须属于同一 Part。全题定义放 domain.definitions，定义原文放 transcription.root.units，definition_use 放使用该定义的局部事实中。
source_gaps 表示原图缺图/不清楚；domain.gaps 表示某条已转录原文未编码。可读内容全编码时 domain.completeness=complete、domain.gaps=[]，即使原图有 source_gaps。不要把缺图再抄成领域缺口。歧义符号保留原样及 source_gap，不能补出平行四边形或正方形条件。
区域 bbox 只能是归一化 [x0,y0,x1,y1]，页码从1开始；没有可靠定位可用空 region_refs。given=原文命名的对象，不意味着固定；只有原文明示定点/动点才使用 fixed/moving。形式参数和定义局部 witness 不与题图点混用。
直接在最终内容输出紧凑 JSON；不要在推理中预写整包 JSON、重复重述 Schema 或多次列出已确定的定义。保留全部逻辑分支，但公共条件放外层 all 一次即可，不为每个分支重复。
输出不能出现 solver_projection、verified_problem、答案、采用状态或 Solver 就绪证明。schema 中没有的字段禁止添加。
"""


def example():
    """Independent generic definition and two scopes; no benchmark facts or answers."""

    def unit(uid, kind, text):
        return {
            "id": uid,
            "kind": kind,
            "text": text,
            "region_refs": [],
            "origin": "printed",
        }

    def vertex(i):
        return {"kind": "polygon_vertex", "polygon": "P", "index": i}

    definition = {
        "id": "balanced",
        "label": "例：均衡形",
        "parameters": [{"id": "P", "kind": "polygon"}],
        "local_witnesses": [{"id": "X", "kind": "point"}],
        "body": {
            "kind": "all",
            "terms": [
                {"kind": "midpoint", "point": "X", "segment": [vertex(0), vertex(2)]},
                {
                    "kind": "any",
                    "terms": [
                        {
                            "kind": "quantity_relation",
                            "operator": "=",
                            "left": {
                                "kind": "segment_length",
                                "segment": ["X", vertex(1)],
                            },
                            "right": {
                                "kind": "segment_length",
                                "segment": ["X", vertex(3)],
                            },
                        },
                        {
                            "kind": "perpendicular",
                            "first": [vertex(0), vertex(2)],
                            "second": [vertex(1), vertex(3)],
                        },
                    ],
                },
            ],
        },
        "source_unit_ids": ["definition_text"],
    }
    t = {
        "schema_version": "problem-transcription/v1",
        "problem_id": "example",
        "source_sha256": "0" * 64,
        "root": {
            "id": "root",
            "title": "独立示例",
            "units": [
                unit(
                    "definition_text",
                    "definition",
                    "称有序四边形的首条对角线中点到另两顶点等距，或两对角线垂直时为均衡形。",
                )
            ],
            "children": [],
        },
        "regions": [],
        "figures": [],
        "source_gaps": [],
    }
    d = {
        "schema_version": "problem-domain/v2",
        "problem_id": "example",
        "source_sha256": "0" * 64,
        "transcription_revision": "",
        "completeness": "complete",
        "definitions": [definition],
        "root": {
            "id": "root_scope",
            "part_ref": "root",
            "entities": [],
            "facts": [],
            "goals": [],
            "children": [],
        },
        "coverage": AUTO_COVERAGE,
        "gaps": [],
    }
    for prefix in ("p1", "p2"):
        given, asked = prefix + "_given", prefix + "_asked"
        t["root"]["children"].append(
            {
                "id": prefix,
                "title": "独立图景 " + prefix,
                "units": [
                    unit(given, "condition", "四边形UVWZ按U、V、W、Z顺序构成均衡形。"),
                    unit(asked, "requirement", "求UV长度。"),
                ],
                "children": [],
            }
        )
        entities = [
            {
                "id": prefix + "_" + label,
                "kind": "point",
                "label": label,
                "role": "given",
                "source_unit_ids": [given],
            }
            for label in "UVWZ"
        ]
        entities.append(
            {
                "id": prefix + "_polygon",
                "kind": "polygon",
                "label": "UVWZ",
                "vertices": [prefix + "_" + label for label in "UVWZ"],
                "source_unit_ids": [given],
            }
        )
        d["root"]["children"].append(
            {
                "id": prefix + "_scope",
                "part_ref": prefix,
                "entities": entities,
                "facts": [
                    {
                        "id": prefix + "_instance",
                        "source_unit_ids": [given],
                        "relation": {
                            "kind": "definition_use",
                            "definition_ref": "balanced",
                            "arguments": {"P": prefix + "_polygon"},
                        },
                    }
                ],
                "goals": [
                    {
                        "id": prefix + "_goal",
                        "kind": "quantity_goal",
                        "expression": {
                            "kind": "segment_length",
                            "segment": [prefix + "_U", prefix + "_V"],
                        },
                        "answer_form": {"kind": "exact_value"},
                        "source_unit_ids": [asked],
                    }
                ],
                "children": [],
            }
        )
    m = {
        "schema_version": "problem-solver-match/v1",
        "transcription_revision": "response.transcription",
        "domain_revision": "response.domain",
        "registry_snapshot": "0" * 64,
        "status": "unmatched",
        "family_id": None,
        "reason": "示例registry为空，没有覆盖这些要求的family。",
        "coverage": [],
        "uncovered_requirements": [
            {
                "source_unit_refs": [p + "_asked"],
                "domain_unit_refs": [p + "_goal"],
                "reason": "示例没有注册此求值能力。",
            }
            for p in ("p1", "p2")
        ],
    }
    d["transcription_revision"] = "response.transcription"
    result = {
        "schema_version": "problem-understanding/v1",
        "transcription": t,
        "domain": d,
        "match": m,
    }
    # Validate the canonical objects from the same source before presenting the example.
    from .service import seal_links

    parse("problem-understanding/v1", seal_links(result))
    return result


def prompt_payload(*, problem_id, source_sha256, registry, observation):
    view, _ = observation_view(observation)
    return {
        "authoring_policy": AUTHORING_POLICY,
        "identity": {
            "problem_id": problem_id,
            "source_sha256": source_sha256,
            "registry_snapshot": revision(registry),
        },
        "family_catalog": registry,
        "observation_auxiliary": view,
        "response_schema": compact_schema(response_schema()),
        "legal_example_with_empty_example_registry": example(),
    }
