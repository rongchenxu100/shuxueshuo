"""Exact revisions and conservative semantic identity, independent of Solver."""

import json
from copy import deepcopy
from hashlib import sha256

from .algebra import scalar_expression


def encoded(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode()


def revision(value):
    return sha256(encoded(value)).hexdigest()


def semantic_payload(value):
    value = deepcopy(value)
    mappings = {
        d["id"]: {p["id"]: f"formal_{i}" for i, p in enumerate(d["parameters"])}
        for d in value.get("definitions", [])
    }
    for definition in value.get("definitions", []):
        mapping = {
            p["id"]: f"formal_{i}" for i, p in enumerate(definition["parameters"])
        }
        mapping.update(
            {
                p["id"]: f"witness_{i}"
                for i, p in enumerate(definition["local_witnesses"])
            }
        )

        def rename(x, mapping=mapping):
            if isinstance(x, str):
                return mapping.get(x, x)
            if isinstance(x, list):
                return [rename(v) for v in x]
            if isinstance(x, dict):
                result = {mapping.get(k, k): rename(v) for k, v in x.items()}
                if x.get("kind") == "scalar_algebra":
                    import re

                    result["expression"] = re.sub(
                        r"\b[A-Za-z_][A-Za-z_0-9]*\b",
                        lambda m: mapping.get(m[0], m[0]),
                        x["expression"],
                    )
                return result
            return x

        definition.update(rename(definition))

    def norm(x):
        if isinstance(x, list):
            return [norm(v) for v in x]
        if not isinstance(x, dict):
            return x
        y = {k: norm(v) for k, v in x.items() if k not in ("transcription_revision",)}
        kind = y.get("kind")
        if kind == "definition_use":
            mapping = mappings.get(y["definition_ref"], {})
            y["arguments"] = {mapping.get(k, k): v for k, v in y["arguments"].items()}
        if kind in ("number", "angle_constant", "measured_constant"):
            y["value"] = str(scalar_expression(y["value"]))
        if kind == "scalar_algebra":
            obligations = []
            y["expression"] = str(
                scalar_expression(y["expression"], y["refs"], obligations)
            )
            if obligations:
                y["algebra_obligations"] = sorted(obligations, key=encoded)
            y["refs"] = sorted(y["refs"])
        if kind in ("add", "multiply"):
            y["terms"] = sorted(y["terms"], key=encoded)
        if kind == "quantity_relation" and y["operator"] in ("=", "!="):
            y["left"], y["right"] = sorted((y["left"], y["right"]), key=encoded)
        return y

    return norm(value)


def semantic_revision(value):
    return revision(semantic_payload(value))
