"""Strict structural gold comparison modulo IDs and supported equivalent spellings.

Coverage links are validated separately. This does not prove source-image truth.
"""

from copy import deepcopy

from .identity import encoded, revision, semantic_payload
from .validation import walk_scopes


def comparison_view(domain):
    d = deepcopy(domain)
    # Alpha rename IDs using lexical scope positions and visible entity labels.
    # Labels on geometry objects are display text: polygon identity uses vertices.
    names = {
        definition["id"]: f"definition{i}"
        for i, definition in enumerate(d["definitions"])
    }
    leaf = 0
    for scope, _ in walk_scopes(d["root"]):
        if not scope["children"]:
            for e in scope["entities"]:
                if e["kind"] in ("point", "scalar"):
                    names[e["id"]] = f"{leaf}:{e['kind']}:{e['label']}"
            for e in scope["entities"]:
                if e["kind"] == "polygon":
                    names[e["id"]] = "polygon:" + "-".join(
                        names.get(v, v) for v in e["vertices"]
                    )
                if e["kind"] in ("ray", "line", "segment"):
                    names[e["id"]] = (
                        e["kind"]
                        + ":"
                        + "-".join(names.get(v, v) for v in e["endpoints"])
                    )
            leaf += 1

    def rename(x):
        if isinstance(x, list):
            return [rename(v) for v in x]
        if isinstance(x, dict):
            return {k: rename(v) for k, v in x.items()}
        return names.get(x, x) if isinstance(x, str) else x

    d = semantic_payload(rename(d))

    def norm(x):
        if isinstance(x, list):
            return [norm(v) for v in x]
        if not isinstance(x, dict):
            return x
        y = {
            k: norm(v)
            for k, v in x.items()
            if k not in ("id", "label", "source_unit_ids")
        }
        if y.get("kind") in ("all", "any", "add", "multiply"):
            y["terms"] = sorted(y["terms"], key=encoded)
        if y.get("kind") in ("segment_length", "midpoint", "point_on_segment"):
            y["segment"] = sorted(y["segment"], key=encoded)
        if y.get("kind") == "angle_measure":
            a, b, c = y["angle"]
            a, c = sorted((a, c), key=encoded)
            y["angle"] = [a, b, c]
        if y.get("kind") == "triangle_area":
            y["vertices"] = sorted(y["vertices"], key=encoded)
        if y.get("kind") == "quantity_relation" and y["operator"] in ("=", "!="):
            y["left"], y["right"] = sorted((y["left"], y["right"]), key=encoded)
        if y.get("kind") in ("parallel", "perpendicular", "intersection"):
            a, b = sorted(y["first"], key=encoded), sorted(y["second"], key=encoded)
            y["first"], y["second"] = sorted((a, b), key=encoded)
        return y

    def flatten(r):
        return (
            [v for x in r["terms"] for v in flatten(x)]
            if r["kind"] == "all"
            else [norm(r)]
        )

    scopes = []
    for s, _ in walk_scopes(d["root"]):
        if s["entities"] or s["facts"] or s["goals"]:
            scopes.append(
                {
                    "entities": sorted(
                        [
                            {"identity": names.get(e["id"], e["id"]), **norm(e)}
                            for e in s["entities"]
                        ],
                        key=encoded,
                    ),
                    "facts": sorted(
                        [v for f in s["facts"] for v in flatten(f["relation"])],
                        key=encoded,
                    ),
                    "goals": sorted([norm(g) for g in s["goals"]], key=encoded),
                }
            )
    return {
        "definitions": [norm(x) for x in d["definitions"]],
        "scopes": scopes,
        "completeness": d["completeness"],
    }


def compare(expected, actual):
    a, b = comparison_view(expected), comparison_view(actual)
    differences = []

    def walk(x, y, path):
        if type(x) != type(y):
            differences.append({"path": path, "expected": x, "actual": y})
            return
        if isinstance(x, dict):
            for k in sorted(x.keys() | y.keys()):
                walk(x.get(k), y.get(k), path + "/" + k)
        elif isinstance(x, list):
            if len(x) != len(y):
                differences.append(
                    {"path": path, "expected_count": len(x), "actual_count": len(y)}
                )
            for i, (u, v) in enumerate(zip(x, y)):
                walk(u, v, path + "/" + str(i))
        elif x != y:
            differences.append({"path": path, "expected": x, "actual": y})

    walk(a, b, "")
    return {
        "ok": not differences,
        "expected_hash": revision(a),
        "actual_hash": revision(b),
        "differences": differences,
    }
