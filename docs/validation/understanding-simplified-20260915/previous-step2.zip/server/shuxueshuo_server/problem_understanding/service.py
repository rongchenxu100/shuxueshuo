"""Candidate-only parsing, immutable artifacts, precise domain edits and safe display."""

import json
from copy import deepcopy
from html import escape

from .authoring import (
    AUTO_COVERAGE,
    coverage_from_links,
    normalize_definition_arguments,
)
from .contracts import errors, schema
from .identity import revision
from .validation import (
    DomainValidator,
    validate_match,
    validate_transcription,
    walk_scopes,
)


def response_schema():
    """Same-response links are explicit wire references; the server seals exact hashes.

    A model cannot calculate a hash of its not-yet-written output. Only these two
    declared self references are resolved; identities and supplied hashes are never
    silently corrected. Persisted contracts always use exact SHA256 revisions.
    """
    result = schema("problem-understanding/v1")

    def replace(x):
        if isinstance(x, dict):
            for key, value in x.items():
                if key in ("transcription_revision", "domain_revision"):
                    x[key] = {"const": "response." + key.removesuffix("_revision")}
                else:
                    replace(value)
        elif isinstance(x, list):
            for v in x:
                replace(v)

    replace(result)
    result["properties"]["domain"]["properties"]["coverage"] = {"const": AUTO_COVERAGE}
    return result


def seal_links(payload):
    result = deepcopy(payload)
    t, d, m = (result.get(k) for k in ("transcription", "domain", "match"))
    if isinstance(d, dict) and d.get("coverage") == AUTO_COVERAGE:
        normalize_definition_arguments(d)
        d["coverage"] = coverage_from_links(d)
    if (
        isinstance(t, dict)
        and isinstance(d, dict)
        and d.get("transcription_revision") == "response.transcription"
    ):
        d["transcription_revision"] = revision(t)
    if isinstance(m, dict):
        if (
            isinstance(t, dict)
            and m.get("transcription_revision") == "response.transcription"
        ):
            m["transcription_revision"] = revision(t)
        if isinstance(d, dict) and m.get("domain_revision") == "response.domain":
            m["domain_revision"] = revision(d)
    return result


def parse_candidate(
    raw,
    *,
    problem_id,
    source_sha256,
    registry_snapshot,
    registered_families,
    store=None,
):
    artifacts = {}

    def save(name, value):
        if store:
            artifacts[name] = store.put_json(
                kind="understanding_" + name, payload=value
            ).to_payload()

    if store:
        artifacts["raw"] = store.put_bytes(
            kind="understanding_raw",
            content=raw.encode(),
            media_type="text/plain",
            suffix=".txt",
        ).to_payload()
    result = {
        "schema_version": "problem-understanding-candidate/v1",
        "candidate_only": True,
        "source_reviewed": False,
        "solver_ready": False,
        "objects": {},
        "reports": {},
        "artifacts": artifacts,
    }
    try:
        # Reject NaN, duplicate keys and trailing garbage rather than picking a prefix.
        def pairs(items):
            d = {}
            for k, v in items:
                if k in d:
                    raise ValueError("duplicate JSON key: " + k)
                d[k] = v
            return d

        payload = json.loads(
            raw,
            object_pairs_hook=pairs,
            parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)),
        )
    except (ValueError, RecursionError) as exc:
        result["reports"]["top"] = {"ok": False, "issues": [str(exc)]}
        return result
    if not isinstance(payload, dict):
        result["reports"]["top"] = {"ok": False, "issues": ["expected object"]}
        return result
    top_ok = (
        set(payload) == {"schema_version", "transcription", "domain", "match"}
        and payload.get("schema_version") == "problem-understanding/v1"
    )
    result["reports"]["top"] = {
        "ok": top_ok,
        "issues": [] if top_ok else ["invalid envelope fields/version"],
    }
    sealed = seal_links(payload)
    for key, contract in [
        ("transcription", "problem-transcription/v1"),
        ("domain", "problem-domain/v2"),
        ("match", "problem-solver-match/v1"),
    ]:
        if key in payload:
            save(key + "_raw", payload[key])
        obj = sealed.get(key)
        issues = errors(contract, obj)
        result["reports"][key] = {"ok": not issues, "issues": issues}
        if not issues:
            result["objects"][key] = obj
            save(key, obj)
    t = result["objects"].get("transcription")
    d = result["objects"].get("domain")
    m = result["objects"].get("match")
    if t:
        result["reports"]["transcription"] = validate_transcription(
            t, problem_id=problem_id, source_sha256=source_sha256
        ).payload()
    if t and d:
        result["reports"]["domain"] = DomainValidator().validate(d, t).payload()
    elif d:
        result["reports"]["domain"] = {
            "ok": False,
            "issues": ["transcription dependency invalid"],
        }
    if t and d and m:
        result["reports"]["match"] = validate_match(
            m,
            d,
            t,
            registry_snapshot=registry_snapshot,
            registered_families=registered_families,
        ).payload()
    elif m:
        result["reports"]["match"] = {
            "ok": False,
            "issues": ["transcription/domain dependency invalid"],
        }
    result["contract_valid"] = all(r["ok"] for r in result["reports"].values())
    save(
        "validation",
        {
            "schema_version": "problem-understanding-validation-bundle/v1",
            "reports": result["reports"],
        },
    )
    if "coverage" in result["reports"].get("domain", {}):
        save(
            "coverage",
            {
                "schema_version": "problem-domain-coverage/v1",
                "domain_revision": revision(d),
                "transcription_revision": revision(t),
                "rows": result["reports"]["domain"]["coverage"],
            },
        )
    return result


def apply_repair(domain, transcription, patch, *, authorized_unit_ids):
    issues = errors("problem-repair/v2", patch)
    if issues:
        raise ValueError("repair.schema: " + "; ".join(issues)[:1024])
    if patch["base_revision"] != revision(domain):
        raise ValueError("repair.stale_revision")
    candidate = deepcopy(domain)
    locations = {}
    for s, _ in walk_scopes(candidate["root"]):
        for key in ("entities", "facts", "goals"):
            for i, unit in enumerate(s[key]):
                locations[unit["id"]] = (s[key], i)
    for i, unit in enumerate(candidate["definitions"]):
        locations[unit["id"]] = (candidate["definitions"], i)
    touched = set()
    for op in patch["replacements"]:
        uid, new = op["unit_id"], op["value"]
        if uid not in authorized_unit_ids or uid not in locations or uid in touched:
            raise ValueError("repair.outside_cone_or_duplicate")
        touched.add(uid)
        collection, index = locations[uid]
        old = collection[index]
        if (
            new["id"] != uid
            or old.get("kind") != new.get("kind")
            or set(old.get("source_unit_ids", []))
            != set(new.get("source_unit_ids", []))
        ):
            raise ValueError("repair.protected_identity_or_source")
        collection[index] = deepcopy(new)
    report = DomainValidator().validate(candidate, transcription)
    if not report.ok:
        raise ValueError(
            "repair.invalid_result: "
            + json.dumps(report.issues, ensure_ascii=False)[:4096]
        )
    return candidate, report


def render_candidate(t, d, report):
    """Render trusted structure with escaped model text; no scripts, math HTML or answers."""
    esc = lambda x: escape(str(x), quote=True)
    rows = [
        '<!doctype html><html lang="zh"><meta charset="utf-8"><title>题意候选</title>',
        "<style>body{max-width:960px;margin:32px auto;font:16px/1.7 system-ui;padding:16px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f5f7;padding:16px}section{border-top:1px solid #ddd}aside{background:#fff5d6;padding:16px}</style>",
        "<h1>已提取题意 · 候选</h1><aside>表达校验与 Solver 匹配独立；本页不表示原图已复核或允许求解。</aside>",
    ]
    for part, depth in walk_scopes(t["root"]):
        rows.append(
            f"<section><h{min(depth + 1, 6)}>{esc(part['title'])}</h{min(depth + 1, 6)}>"
        )
        for u in part["units"]:
            rows.append(
                f"<p><b>{esc(u['kind'])}</b> {esc(u['text'])} <small>({esc(u['id'])})</small></p>"
            )
        rows.append("</section>")
    for heading, payload in [
        ("来源缺口", t["source_gaps"]),
        ("定义及完整分支", d["definitions"]),
        ("条件和所求", d["root"]),
        ("未编码原文", d["gaps"]),
        ("待证明义务（不是题设）", report.well_definedness_obligations),
    ]:
        rows.append(
            "<h2>"
            + heading
            + "</h2><pre>"
            + esc(json.dumps(payload, ensure_ascii=False, indent=2))
            + "</pre>"
        )
    rows.append("</html>")
    return "\n".join(rows)
