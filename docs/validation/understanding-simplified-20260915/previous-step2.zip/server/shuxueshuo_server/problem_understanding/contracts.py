"""Authoritative versioned contracts; parsers and prompt schemas use this source."""

from __future__ import annotations

import json
from copy import deepcopy

from jsonschema import Draft202012Validator


def obj(**properties):
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


def array(items, minimum=0, maximum=256):
    return {"type": "array", "items": items, "minItems": minimum, "maxItems": maximum}


def enum(*values):
    return {"enum": list(values)}


def ref(name):
    return {"$ref": f"#/$defs/{name}"}


def variant(kind, **fields):
    return obj(kind={"const": kind}, **fields)


TEXT = {"type": "string", "minLength": 1, "maxLength": 8192}
ID = {"type": "string", "pattern": r"^[A-Za-z][A-Za-z0-9_.:-]{0,127}$"}
HASH = {"type": "string", "pattern": "^[a-f0-9]{64}$"}
REFS = array(ID, 1)
EXPR = {"type": "string", "minLength": 1, "maxLength": 1024}
POINT = {
    "oneOf": [
        ID,
        variant(
            "polygon_vertex",
            polygon=ID,
            index={"type": "integer", "minimum": 0, "maximum": 3},
        ),
    ]
}
SEGMENT = array(POINT, 2, 2)
ANGLE = array(POINT, 3, 3)
Q = ref("QuantityTerm")
REL = ref("Relation")
NUMBER = variant("number", value=EXPR)
SCALAR = variant("scalar", symbol_ref=ID)

DEFS = {
    "Region": obj(
        id=ID,
        page={"type": "integer", "minimum": 1},
        bbox=array({"type": "number", "minimum": 0, "maximum": 1}, 4, 4),
    ),
    "SourceUnit": obj(
        id=ID,
        kind=enum("text", "condition", "requirement", "definition"),
        text=TEXT,
        region_refs=array(ID),
        origin=enum("printed", "unknown", "mixed", "handwritten"),
    ),
    "Part": obj(
        id=ID,
        title=TEXT,
        units=array(ref("SourceUnit")),
        children=array(ref("Part"), 0, 16),
    ),
    "SourceGap": obj(
        id=ID,
        reason=enum("missing_figure", "unreadable", "ambiguous_symbol", "occluded"),
        description=TEXT,
        part_ref=ID,
        source_unit_refs=array(ID),
        region_refs=array(ID),
    ),
    "Figure": obj(
        id=ID,
        label=TEXT,
        part_ref=ID,
        available={"type": "boolean"},
        region_refs=array(ID),
    ),
    "QuantityTerm": {
        "oneOf": [
            NUMBER,
            SCALAR,
            variant("scalar_algebra", expression=EXPR, refs=array(ID)),
            variant("segment_length", segment=SEGMENT),
            variant("angle_measure", angle=ANGLE, unit={"const": "degree"}),
            variant("angle_constant", value=EXPR, unit={"const": "degree"}),
            variant("triangle_area", vertices=ANGLE, convention={"const": "unsigned"}),
            variant("add", terms=array(Q, 2, 256)),
            variant("multiply", terms=array(Q, 2, 256)),
            variant("divide", numerator=Q, denominator=Q),
            variant("tan", angle=Q),
        ]
    },
    "Entity": {
        "oneOf": [
            obj(
                id=ID,
                kind=enum("point"),
                label=TEXT,
                role=enum("given", "fixed", "moving", "constructed"),
            ),
            obj(id=ID, kind=enum("scalar", "curve"), label=TEXT),
            obj(id=ID, kind=enum("polygon"), label=TEXT, vertices=array(POINT, 3, 8)),
            obj(
                id=ID,
                kind=enum("ray", "line", "segment"),
                label=TEXT,
                endpoints=SEGMENT,
            ),
        ]
    },
    "Relation": {
        "oneOf": [
            variant(
                "quantity_relation",
                operator=enum("=", "!=", ">", ">=", "<", "<="),
                left=Q,
                right=Q,
            ),
            variant("all", terms=array(REL, 1)),
            variant("any", terms=array(REL, 2)),
            variant("midpoint", point=POINT, segment=SEGMENT),
            variant(
                "intersection",
                point=POINT,
                first=SEGMENT,
                second=SEGMENT,
                interior={"type": "boolean"},
            ),
            variant("diagonal", polygon=ID, endpoints=SEGMENT),
            variant("parallel", first=SEGMENT, second=SEGMENT),
            variant("perpendicular", first=SEGMENT, second=SEGMENT),
            variant("point_on_ray", point=POINT, ray=ID),
            variant(
                "point_on_segment",
                point=POINT,
                segment=SEGMENT,
                interior={"type": "boolean"},
            ),
            variant("parallelogram", polygon=ID),
            variant("square", polygon=ID),
            variant("diagonal_bisects", polygon=ID, bisector=SEGMENT, bisected=SEGMENT),
            variant("coordinates", point=POINT, x=Q, y=Q),
            variant(
                "curve_equation", curve=ID, expression=Q, independent=ID, dependent=ID
            ),
            variant("point_on_curve", point=POINT, curve=ID),
            variant(
                "definition_use",
                definition_ref=ID,
                arguments={
                    "type": "object",
                    "additionalProperties": {"oneOf": [ID, Q]},
                    "maxProperties": 16,
                },
            ),
        ]
    },
    "Fact": obj(id=ID, relation=REL, source_unit_ids=REFS),
    "AnswerForm": {
        "oneOf": [variant("exact_value"), variant("expression_in", parameters=REFS)]
    },
    "Goal": {
        "oneOf": [
            obj(
                id=ID,
                kind=enum("quantity_goal"),
                expression=Q,
                answer_form=ref("AnswerForm"),
                source_unit_ids=REFS,
            ),
            obj(
                id=ID, kind=enum("coordinates_goal"), point=POINT, source_unit_ids=REFS
            ),
            obj(id=ID, kind=enum("equation_goal"), curve=ID, source_unit_ids=REFS),
            obj(
                id=ID,
                kind=enum("extremum_goal"),
                expression=Q,
                direction=enum("minimum", "maximum"),
                variables=REFS,
                constraints=array(REL),
                answer_form=ref("AnswerForm"),
                source_unit_ids=REFS,
            ),
        ]
    },
    "Scope": obj(
        id=ID,
        part_ref=ID,
        entities=array(ref("Entity"), 0, 128),
        facts=array(ref("Fact"), 0, 128),
        goals=array(ref("Goal"), 0, 64),
        children=array(ref("Scope"), 0, 16),
    ),
    "Formal": obj(id=ID, kind=enum("polygon", "scalar")),
    "Definition": obj(
        id=ID,
        label=TEXT,
        parameters=array(ref("Formal"), 1, 16),
        local_witnesses=array(obj(id=ID, kind=enum("point")), 0, 16),
        body=REL,
        source_unit_ids=REFS,
    ),
    "Coverage": obj(
        source_unit_id=ID,
        domain_unit_ids=array(ID),
        gap_id={"oneOf": [ID, {"type": "null"}]},
    ),
    "DomainGap": obj(id=ID, source_unit_id=ID, reason=TEXT),
    "Uncovered": obj(source_unit_refs=REFS, domain_unit_refs=REFS, reason=TEXT),
    "MatchCoverage": obj(requirement_ref=ID, domain_unit_refs=REFS),
}

# Coordinate/construction and optimization primitives shared with quadratic tasks.
DEFS["QuantityTerm"]["oneOf"].extend(
    [
        variant("measured_constant", value=EXPR, unit=enum("length", "area")),
        variant("coordinate_component", point=POINT, axis=enum("x", "y")),
    ]
)
DEFS["Relation"]["oneOf"].extend(
    [
        variant("origin", point=POINT),
        variant("translation", point=POINT, original=POINT, vector=array(Q, 2, 2)),
        variant(
            "curve_landmark",
            point=POINT,
            curve=ID,
            landmark=enum(
                "vertex", "x_axis_intercept", "y_axis_intercept", "axis_x_intercept"
            ),
            side=enum(None, "left", "right"),
            exclude_point={"oneOf": [POINT, {"type": "null"}]},
        ),
        variant("curve_at_x", point=POINT, curve=ID, x=Q),
        variant(
            "point_on_axis",
            point=POINT,
            axis=enum("x", "y", "symmetry"),
            curve={"oneOf": [ID, {"type": "null"}]},
        ),
        variant(
            "extremum_constraint",
            direction=enum("minimum", "maximum"),
            expression=Q,
            variables=REFS,
            value={"oneOf": [Q, {"type": "null"}]},
        ),
    ]
)

for entity_schema in DEFS["Entity"]["oneOf"]:
    entity_schema["properties"]["source_unit_ids"] = REFS
    entity_schema["required"].append("source_unit_ids")

TRANSCRIPTION = obj(
    schema_version={"const": "problem-transcription/v1"},
    problem_id=ID,
    source_sha256=HASH,
    root=ref("Part"),
    regions=array(ref("Region")),
    figures=array(ref("Figure")),
    source_gaps=array(ref("SourceGap")),
)
DOMAIN = obj(
    schema_version={"const": "problem-domain/v2"},
    problem_id=ID,
    source_sha256=HASH,
    transcription_revision=HASH,
    completeness=enum("complete", "partial"),
    root=ref("Scope"),
    definitions=array(ref("Definition"), 0, 8),
    coverage=array(ref("Coverage")),
    gaps=array(ref("DomainGap")),
)
MATCH_COMMON = {
    "schema_version": {"const": "problem-solver-match/v1"},
    "transcription_revision": HASH,
    "domain_revision": HASH,
    "registry_snapshot": HASH,
    "reason": TEXT,
}
MATCH = {
    "oneOf": [
        obj(
            **MATCH_COMMON,
            status={"const": "matched"},
            family_id=ID,
            coverage=array(ref("MatchCoverage"), 1),
            uncovered_requirements=array(ref("Uncovered"), 0, 0),
        ),
        obj(
            **MATCH_COMMON,
            status={"const": "unmatched"},
            family_id={"type": "null"},
            coverage=array(ref("MatchCoverage")),
            uncovered_requirements=array(ref("Uncovered"), 1),
        ),
    ]
}
UNDERSTANDING = obj(
    schema_version={"const": "problem-understanding/v1"},
    transcription=TRANSCRIPTION,
    domain=DOMAIN,
    match=MATCH,
)
PATCH_UNIT = {"oneOf": [ref("Entity"), ref("Fact"), ref("Goal"), ref("Definition")]}
REPAIR = obj(
    schema_version={"const": "problem-repair/v2"},
    base_revision=HASH,
    replacements=array(obj(unit_id=ID, value=PATCH_UNIT), 1, 32),
)
CONTRACTS = {
    "problem-transcription/v1": TRANSCRIPTION,
    "problem-domain/v2": DOMAIN,
    "problem-solver-match/v1": MATCH,
    "problem-understanding/v1": UNDERSTANDING,
    "problem-repair/v2": REPAIR,
}


def schema(contract):
    return deepcopy(
        {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            **CONTRACTS[contract],
            "$defs": DEFS,
        }
    )


def errors(contract, payload):
    pending = [(payload, 0)]
    count = 0
    while pending:
        value, depth = pending.pop()
        count += 1
        if depth > 96 or count > 100_000:
            return ["contract.resource_limit"]
        if isinstance(value, dict):
            pending.extend((v, depth + 1) for v in value.values())
        elif isinstance(value, list):
            pending.extend((v, depth + 1) for v in value)
    return [
        f"/{'/'.join(map(str, e.absolute_path))}: {e.message}"
        for e in Draft202012Validator(schema(contract)).iter_errors(payload)
    ]


def parse(contract, payload):
    if isinstance(payload, str):
        payload = json.loads(payload)
    issues = errors(contract, payload)
    if issues:
        raise ValueError("; ".join(issues)[:4096])
    return deepcopy(payload)
