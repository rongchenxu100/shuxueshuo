"""Structural, lexical, dimensional and coverage checks. No family or Solver dependency."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field

from .algebra import scalar_expression
from .contracts import errors
from .identity import encoded, revision


@dataclass
class Report:
    issues: list = field(default_factory=list)
    well_definedness_obligations: list = field(default_factory=list)
    coverage: list = field(default_factory=list)
    expanded_instances: list = field(default_factory=list)

    @property
    def ok(self):
        return not self.issues

    def error(self, code, unit="", detail=""):
        self.issues.append({"code": code, "unit": unit, "detail": detail})

    def obligation(self, code, unit, expression):
        item = {
            "code": code,
            "unit": unit,
            "expression": expression,
            "status": "unproved",
        }
        if item not in self.well_definedness_obligations:
            self.well_definedness_obligations.append(item)

    def payload(self):
        return {
            "schema_version": "problem-understanding-validation/v1",
            "ok": self.ok,
            "issues": self.issues,
            "well_definedness_obligations": self.well_definedness_obligations,
            "coverage": self.coverage,
            "expanded_instances": self.expanded_instances,
        }


def walk_scopes(root, depth=1):
    yield root, depth
    for child in root["children"]:
        yield from walk_scopes(child, depth + 1)


def source_index(t):
    return {
        u["id"]: (p["id"], u) for p, _ in walk_scopes(t["root"]) for u in p["units"]
    }


def validate_transcription(t, *, problem_id, source_sha256, page_count=1):
    r = Report()
    for e in errors("problem-transcription/v1", t):
        r.error("transcription.schema", detail=e)
    if not r.ok:
        return r
    if t["problem_id"] != problem_id or t["source_sha256"] != source_sha256:
        r.error("source.identity_mismatch")
    ids = set()

    def unique(i):
        if i in ids:
            r.error("source.duplicate_id", i)
        ids.add(i)

    parts = set()
    for p, depth in walk_scopes(t["root"]):
        unique(p["id"])
        parts.add(p["id"])
        if depth > 4:
            r.error("scope.depth_limit", p["id"])
        for u in p["units"]:
            unique(u["id"])
    units = source_index(t)
    regions = {v["id"] for v in t["regions"]}
    for region in t["regions"]:
        unique(region["id"])
        x0, y0, x1, y1 = region["bbox"]
        if x0 >= x1 or y0 >= y1 or region["page"] > page_count:
            r.error("source.invalid_region", region["id"])
    for _, u in units.values():
        if not set(u["region_refs"]) <= regions:
            r.error("source.unknown_region", u["id"])
    gaps = set()
    for g in t["source_gaps"]:
        unique(g["id"])
        gaps.add(g["part_ref"])
        if (
            g["part_ref"] not in parts
            or not set(g["source_unit_refs"]) <= units.keys()
            or not set(g["region_refs"]) <= regions
        ):
            r.error("source.gap_reference", g["id"])
    for f in t["figures"]:
        unique(f["id"])
        if f["part_ref"] not in parts or not set(f["region_refs"]) <= regions:
            r.error("source.figure_reference", f["id"])
        if not f["available"] and f["part_ref"] not in gaps:
            r.error("source.missing_figure_gap", f["id"])
    return r


class DomainValidator:
    def validate(self, d, t):
        self.r = r = Report()
        for e in errors("problem-domain/v2", d):
            r.error("domain.schema", detail=e)
        if not r.ok:
            return r
        if errors("problem-transcription/v1", t):
            r.error("domain.invalid_transcription")
            return r
        if (d["problem_id"], d["source_sha256"], d["transcription_revision"]) != (
            t["problem_id"],
            t["source_sha256"],
            revision(t),
        ):
            r.error("domain.stale_transcription")
        self.units = source_index(t)
        self.parts = {p["id"] for p, _ in walk_scopes(t["root"])}
        self.defs = {x["id"]: x for x in d["definitions"]}
        self.seen = set()
        self.graph = {}
        self.expanded_nodes = 0
        self.instance_count = 0
        self.witness_sequence = 0
        if not d["definitions"] and not any(
            s["entities"] or s["facts"] or s["goals"] for s, _ in walk_scopes(d["root"])
        ):
            r.error("domain.empty_graph")
        # Definition graph cycle/depth check is performed even for unused definitions.
        for definition in d["definitions"]:
            self.unique(definition["id"])
            self.graph[definition["id"]] = (t["root"]["id"], definition)
            self.sources(definition, t["root"]["id"])
            formals = definition["parameters"] + definition["local_witnesses"]
            if len({p["id"] for p in formals}) != len(formals):
                r.error("definition.duplicate_formal", definition["id"])
            env = {p["id"]: p for p in formals}

            def constructed_points(node):
                if node["kind"] in ("all", "any"):
                    return {
                        p for child in node["terms"] for p in constructed_points(child)
                    }
                point = node.get("point")
                return (
                    {point}
                    if node["kind"] in ("intersection", "midpoint", "coordinates")
                    and isinstance(point, str)
                    else set()
                )

            constructed = constructed_points(definition["body"])
            for witness in definition["local_witnesses"]:
                if witness["id"] not in constructed:
                    r.error(
                        "definition.unconstructed_witness",
                        definition["id"],
                        witness["id"],
                    )
            self.relation(
                definition["body"],
                env,
                definition["id"],
                stack=(definition["id"],),
                template=True,
            )

        def scope(s, inherited, depth):
            self.unique(s["id"])
            if depth > 4:
                r.error("scope.depth_limit", s["id"])
            if s["part_ref"] not in self.parts:
                r.error("scope.part_missing", s["id"])
            env = dict(inherited)
            for e in s["entities"]:
                self.unique(e["id"])
                if e["id"] in env:
                    r.error("scope.shadowing", e["id"])
                env[e["id"]] = e
                self.graph[e["id"]] = (s["part_ref"], e)
            for e in s["entities"]:
                self.sources(e, s["part_ref"])
                if e["kind"] == "polygon":
                    points = [
                        self.point(p, env, e["id"]) if isinstance(p, str) else "?"
                        for p in e["vertices"]
                    ]
                    if "?" in points:
                        r.error("geometry.entity_vertices_require_points", e["id"])
                    labels = [env.get(p, {}).get("label", "") for p in points]
                    if (
                        all(len(label) == 1 and label.isalpha() for label in labels)
                        and sorted(e["label"]) == sorted("".join(labels))
                        and e["label"] != "".join(labels)
                    ):
                        r.error("geometry.polygon_label_order", e["id"])
                    if len(set(points)) != len(points):
                        r.error("geometry.degenerate_polygon", e["id"])
                    else:
                        r.obligation(
                            "simple_nondegenerate_polygon", e["id"], e["vertices"]
                        )
                if e["kind"] in ("ray", "line", "segment"):
                    self.segment(e["endpoints"], env, e["id"])
            for f in s["facts"]:
                self.unique(f["id"])
                self.graph[f["id"]] = (s["part_ref"], f)
                self.sources(f, s["part_ref"])
                self.relation(f["relation"], env, f["id"])
            for g in s["goals"]:
                self.unique(g["id"])
                self.graph[g["id"]] = (s["part_ref"], g)
                self.sources(g, s["part_ref"])
                if g["kind"] in ("quantity_goal", "extremum_goal"):
                    self.quantity(g["expression"], env, g["id"])
                    for p in g["answer_form"].get("parameters", []):
                        self.entity(p, "scalar", env, g["id"])
                elif g["kind"] == "coordinates_goal":
                    self.point(g["point"], env, g["id"])
                else:
                    self.entity(g["curve"], "curve", env, g["id"])
                if g["kind"] == "extremum_goal":
                    for v in g["variables"]:
                        self.entity(v, ("scalar", "point"), env, g["id"])
                    for relation in g["constraints"]:
                        self.relation(relation, env, g["id"])
            # Only literal contradictions; never infer source conditions from obligations.
            relations = [
                f["relation"]
                for f in s["facts"]
                if f["relation"]["kind"] == "quantity_relation"
            ]
            pairs = {}
            for rel in relations:
                key = tuple(sorted((encoded(rel["left"]), encoded(rel["right"]))))
                ops = pairs.setdefault(key, set())
                ops.add(rel["operator"])
                if "=" in ops and ops & {"!=", ">", "<"}:
                    r.error("quantity.conflicting_relations", s["id"])
            for child in s["children"]:
                scope(child, env, depth + 1)

        scope(d["root"], {}, 1)
        self.check_coverage(d)
        return r

    def unique(self, i):
        if i in self.seen:
            self.r.error("domain.duplicate_id", i)
        self.seen.add(i)

    def sources(self, unit, part):
        for sid in unit["source_unit_ids"]:
            if sid not in self.units or self.units[sid][0] != part:
                self.r.error("source.cross_part_or_missing", unit["id"], sid)
            elif self.units[sid][1]["origin"] in ("handwritten", "mixed", "unknown"):
                self.r.error("source.unconfirmed_condition", unit["id"], sid)

    def entity(self, name, kind, env, unit):
        kinds = (kind,) if isinstance(kind, str) else kind
        if name not in env or env[name]["kind"] not in kinds:
            self.r.error("reference.type_or_scope", unit, str(name))
            return {}
        return env[name]

    def point(self, p, env, unit):
        if isinstance(p, str):
            self.entity(p, "point", env, unit)
            return p
        polygon = self.entity(p["polygon"], "polygon", env, unit)
        vertices = polygon.get("vertices")
        if vertices is None:
            return f"{p['polygon']}[{p['index']}]"
        if p["index"] >= len(vertices):
            self.r.error("geometry.vertex_index", unit)
            return "?"
        selected = vertices[p["index"]]
        if not isinstance(selected, str):
            self.r.error("geometry.recursive_vertex", unit)
            return "?"
        return self.point(selected, env, unit)

    def segment(self, points, env, unit):
        result = [self.point(p, env, unit) for p in points]
        if result[0] == result[1]:
            self.r.error("geometry.degenerate_segment", unit)
        return result

    def quantity(self, q, env, unit, depth=1, counter=None):
        counter = counter if counter is not None else [0]
        counter[0] += 1
        self.expanded_nodes += 1
        if self.expanded_nodes > 4096:
            self.r.error("definition.expansion_limit", unit)
            return (0, 0), None
        if depth > 32 or counter[0] > 256:
            self.r.error("quantity.resource_limit", unit)
            return (0, 0), None
        kind = q["kind"]
        dim, value = (0, 0), None  # exponents of length and angle
        if kind in ("number", "angle_constant", "scalar_algebra", "measured_constant"):
            refs = q.get("refs", [])
            for ref in refs:
                self.entity(ref, "scalar", env, unit)
            try:
                obligations = []
                value = scalar_expression(
                    q.get("value", q.get("expression")), refs, obligations
                )
                for obligation in obligations:
                    self.r.obligation(
                        obligation["code"], unit, obligation["expression"]
                    )
                if value.free_symbols:
                    for denom in [value.as_numer_denom()[1]]:
                        if denom != 1:
                            self.r.obligation(
                                "nonzero_algebra_denominator", unit, str(denom)
                            )
                    value = None
            except ValueError as exc:
                self.r.error(str(exc), unit)
            if kind == "measured_constant":
                dim = (1 if q["unit"] == "length" else 2, 0)
            if kind == "angle_constant":
                dim = (0, 1)
                if value is not None and not 0 <= value <= 180:
                    self.r.error("angle.out_of_range", unit)
        elif kind == "coordinate_component":
            self.point(q["point"], env, unit)
        elif kind == "scalar":
            self.entity(q["symbol_ref"], "scalar", env, unit)
        elif kind == "segment_length":
            self.segment(q["segment"], env, unit)
            dim = (1, 0)
        elif kind in ("angle_measure", "triangle_area"):
            ps = [self.point(p, env, unit) for p in q.get("angle", q.get("vertices"))]
            dim = (0, 1) if kind == "angle_measure" else (2, 0)
            if len(set(ps)) != 3:
                self.r.error("geometry.degenerate_" + kind, unit)
            else:
                self.r.obligation("nondegenerate_" + kind, unit, q)
        elif kind in ("add", "multiply"):
            terms = [
                self.quantity(v, env, unit, depth + 1, counter) for v in q["terms"]
            ]
            if kind == "add":
                dim = terms[0][0]
                if any(d != dim for d, _ in terms):
                    self.r.error("quantity.dimension_mismatch", unit)
                if all(v is not None for _, v in terms):
                    value = sum(v for _, v in terms)
            else:
                dim = tuple(sum(d[i] for d, _ in terms) for i in (0, 1))
                if all(v is not None for _, v in terms):
                    value = 1
                    for _, v in terms:
                        value *= v
        elif kind == "divide":
            a, av = self.quantity(q["numerator"], env, unit, depth + 1, counter)
            b, bv = self.quantity(q["denominator"], env, unit, depth + 1, counter)
            dim = tuple(a[i] - b[i] for i in (0, 1))
            if bv == 0:
                self.r.error("quantity.zero_denominator", unit)
            elif bv is None:
                self.r.obligation("nonzero_denominator", unit, q["denominator"])
            elif av is not None:
                value = av / bv
        elif kind == "tan":
            ad, av = self.quantity(q["angle"], env, unit, depth + 1, counter)
            if ad != (0, 1):
                self.r.error("quantity.tan_requires_angle", unit)
            if av is not None and (av - 90) % 180 == 0:
                self.r.error("quantity.undefined_tangent", unit)
            elif av is None:
                self.r.obligation("tangent_defined", unit, q["angle"])
        return dim, value

    def relation(self, rel, env, unit, stack=(), template=False, depth=0):
        if depth > 32:
            self.r.error("relation.depth_limit", unit)
            return
        self.expanded_nodes += 1
        if self.expanded_nodes > 4096:
            self.r.error("definition.expansion_limit", unit)
            return
        k = rel["kind"]
        if k in ("all", "any"):
            for x in rel["terms"]:
                self.relation(x, env, unit, stack, template, depth + 1)
        elif k == "quantity_relation":
            a, av = self.quantity(rel["left"], env, unit)
            b, bv = self.quantity(rel["right"], env, unit)
            if a != b:
                self.r.error("quantity.dimension_mismatch", unit)
            if av is not None and bv is not None:
                checks = {
                    "=": av == bv,
                    "!=": av != bv,
                    ">": av > bv,
                    ">=": av >= bv,
                    "<": av < bv,
                    "<=": av <= bv,
                }
                if not checks[rel["operator"]]:
                    self.r.error("quantity.literal_contradiction", unit)
        elif k in ("midpoint", "point_on_segment"):
            p = self.point(rel["point"], env, unit)
            ends = self.segment(rel["segment"], env, unit)
            if p in ends and (k == "midpoint" or rel.get("interior")):
                self.r.error("geometry.degenerate_midpoint", unit)
        elif k in ("parallel", "perpendicular", "intersection"):
            a = self.segment(rel["first"], env, unit)
            b = self.segment(rel["second"], env, unit)
            if k == "intersection":
                p = self.point(rel["point"], env, unit)
                if rel["interior"] and p in a + b:
                    self.r.error("geometry.degenerate_intersection", unit)
                if set(a) == set(b):
                    self.r.error("geometry.nonunique_intersection", unit)
            elif k == "perpendicular" and set(a) == set(b):
                self.r.error("geometry.self_perpendicular", unit)
        elif k in ("diagonal", "diagonal_bisects", "square", "parallelogram"):
            p = self.entity(rel["polygon"], "polygon", env, unit)
            vs = p.get("vertices")
            if vs and len(vs) != 4:
                self.r.error("geometry.requires_quadrilateral", unit)
            if k in ("diagonal", "diagonal_bisects"):
                targets = (
                    [rel["endpoints"]]
                    if k == "diagonal"
                    else [rel["bisector"], rel["bisected"]]
                )
                actual = [self.segment(x, env, unit) for x in targets]
                if vs and len(vs) == 4:
                    diagonals = {frozenset([vs[0], vs[2]]), frozenset([vs[1], vs[3]])}
                    if any(frozenset(x) not in diagonals for x in actual) or (
                        len(actual) == 2 and set(actual[0]) == set(actual[1])
                    ):
                        self.r.error("geometry.wrong_diagonal", unit)
        elif k == "point_on_ray":
            self.point(rel["point"], env, unit)
            self.entity(rel["ray"], "ray", env, unit)
        elif k == "coordinates":
            self.point(rel["point"], env, unit)
            for coordinate in (rel["x"], rel["y"]):
                if self.quantity(coordinate, env, unit)[0] != (0, 0):
                    self.r.error("coordinate.requires_scalar", unit)
        elif k in ("curve_equation", "point_on_curve"):
            self.entity(rel["curve"], "curve", env, unit)
            if k == "point_on_curve":
                self.point(rel["point"], env, unit)
            else:
                self.entity(rel["independent"], "scalar", env, unit)
                self.entity(rel["dependent"], "scalar", env, unit)
                if self.quantity(rel["expression"], env, unit)[0] != (0, 0):
                    self.r.error("curve.requires_scalar", unit)
        elif k in (
            "origin",
            "translation",
            "curve_landmark",
            "curve_at_x",
            "point_on_axis",
        ):
            self.point(rel["point"], env, unit)
            if k == "translation":
                self.point(rel["original"], env, unit)
                for v in rel["vector"]:
                    if self.quantity(v, env, unit)[0] != (0, 0):
                        self.r.error("coordinate.requires_scalar", unit)
            if k in ("curve_landmark", "curve_at_x") or (
                k == "point_on_axis" and rel["axis"] == "symmetry"
            ):
                self.entity(rel["curve"], "curve", env, unit)
            if k == "curve_at_x" and self.quantity(rel["x"], env, unit)[0] != (0, 0):
                self.r.error("coordinate.requires_scalar", unit)
            if k == "curve_landmark" and rel["exclude_point"] is not None:
                self.point(rel["exclude_point"], env, unit)
                if rel["point"] == rel["exclude_point"]:
                    self.r.error("geometry.excluded_self", unit)
        elif k == "extremum_constraint":
            dim, _ = self.quantity(rel["expression"], env, unit)
            for v in rel["variables"]:
                self.entity(v, ("point", "scalar"), env, unit)
            if (
                rel["value"] is not None
                and self.quantity(rel["value"], env, unit)[0] != dim
            ):
                self.r.error("quantity.dimension_mismatch", unit)
        elif k == "definition_use":
            self.instantiate(rel, env, unit, stack, template)

    def instantiate(self, rel, env, unit, stack, template):
        name = rel["definition_ref"]
        if name not in self.defs:
            self.r.error("definition.unknown", unit)
            return
        if name in stack or len(stack) >= 4:
            self.r.error("definition.cycle_or_depth", unit)
            return
        self.instance_count += not template
        if self.instance_count > 32:
            self.r.error("definition.instance_limit", unit)
            return
        definition = self.defs[name]
        args = rel["arguments"]
        if set(args) != {p["id"] for p in definition["parameters"]}:
            self.r.error("definition.arguments", unit)
            return
        for p in definition["parameters"]:
            a = args[p["id"]]
            if p["kind"] == "polygon":
                if not isinstance(a, str):
                    self.r.error("definition.argument_type", unit)
                    return
                polygon = self.entity(a, "polygon", env, unit)
                if polygon.get("vertices") and len(polygon["vertices"]) != 4:
                    self.r.error("definition.quadrilateral_required", unit)
                    return
            elif isinstance(a, str) or self.quantity(a, env, unit)[0] != (0, 0):
                self.r.error("definition.argument_type", unit)
                return
        self.witness_sequence += 1
        instance = f"{unit}.instance{self.witness_sequence}"
        witnesses = {
            w["id"]: f"{instance}.{w['id']}" for w in definition["local_witnesses"]
        }

        def subst(x):
            if isinstance(x, list):
                return [subst(v) for v in x]
            if isinstance(x, dict):
                if x.get("kind") == "scalar" and x["symbol_ref"] in args:
                    return deepcopy(args[x["symbol_ref"]])
                if x.get("kind") == "polygon_vertex":
                    p = args.get(x["polygon"], x["polygon"])
                    if not isinstance(p, str):
                        self.r.error("definition.argument_type", unit)
                        return deepcopy(x)
                    vertices = env.get(p, {}).get("vertices")
                    return (
                        deepcopy(vertices[x["index"]])
                        if vertices
                        else {**x, "polygon": p}
                    )
                return {k: subst(v) for k, v in x.items()}
            if isinstance(x, str):
                if x in witnesses:
                    return witnesses[x]
                if x in args and isinstance(args[x], str):
                    return args[x]
            return x

        body = subst(definition["body"])
        local = dict(env)
        for w in witnesses.values():
            if w in local:
                self.r.error("definition.witness_collision", unit, w)
                return
            local[w] = {"id": w, "kind": "point"}
        self.relation(body, local, unit, (*stack, name), template)
        if not template:
            self.r.expanded_instances.append(
                {
                    "instance_id": instance,
                    "definition_id": name,
                    "domain_unit_id": unit,
                    "source_unit_ids": self.graph.get(unit, (None, {}))[1].get(
                        "source_unit_ids", []
                    ),
                    "definition_source_unit_ids": definition["source_unit_ids"],
                    "witnesses": list(witnesses.values()),
                    "body": body,
                }
            )

    def check_coverage(self, d):
        required = {
            sid
            for sid, (_, u) in self.units.items()
            if u["kind"] in ("condition", "requirement", "definition")
        }
        gaps = {g["id"]: g for g in d["gaps"]}
        rows = {}
        for row in d["coverage"]:
            sid = row["source_unit_id"]
            if sid in rows or sid not in self.units:
                self.r.error("coverage.duplicate_or_unknown", sid)
            rows[sid] = row
            if bool(row["domain_unit_ids"]) == bool(row["gap_id"]):
                self.r.error("coverage.graph_xor_gap", sid)
            for uid in row["domain_unit_ids"]:
                pair = self.graph.get(uid)
                if (
                    pair is None
                    or pair[0] != self.units.get(sid, ("",))[0]
                    or sid not in pair[1].get("source_unit_ids", [])
                ):
                    self.r.error("coverage.false_reference", uid, sid)
                elif self.units[sid][1]["kind"] == "requirement" and not pair[1].get(
                    "kind", ""
                ).endswith("_goal"):
                    self.r.error("coverage.requirement_without_goal", uid, sid)
            if row["gap_id"] and (
                row["gap_id"] not in gaps
                or gaps[row["gap_id"]]["source_unit_id"] != sid
            ):
                self.r.error("coverage.invalid_gap", sid)
        for sid in required - rows.keys():
            self.r.error("coverage.missing_source_unit", sid)
        if d["completeness"] == "complete" and d["gaps"]:
            self.r.error("coverage.complete_with_gaps")
        if d["completeness"] == "partial" and not d["gaps"]:
            self.r.error("coverage.partial_without_gaps")
        if {row["gap_id"] for row in rows.values() if row["gap_id"]} != gaps.keys():
            self.r.error("coverage.unused_gap")
        self.r.coverage = deepcopy(d["coverage"])


def validate_match(m, d, t, *, registry_snapshot, registered_families):
    r = Report()
    for e in errors("problem-solver-match/v1", m):
        r.error("match.schema", detail=e)
    if not r.ok:
        return r
    if (m["transcription_revision"], m["domain_revision"], m["registry_snapshot"]) != (
        revision(t),
        revision(d),
        registry_snapshot,
    ):
        r.error("match.stale_binding")
    units = source_index(t)
    graph = {
        x["id"]: x for s, _ in walk_scopes(d["root"]) for x in s["facts"] + s["goals"]
    }
    graph.update({x["id"]: x for x in d["definitions"]})
    requirements = {i for i, (_, u) in units.items() if u["kind"] == "requirement"}
    covered = set()
    for row in m["coverage"]:
        sid = row["requirement_ref"]
        if (
            sid in covered
            or sid not in requirements
            or any(
                uid not in graph or sid not in graph[uid].get("source_unit_ids", [])
                for uid in row["domain_unit_refs"]
            )
        ):
            r.error("match.false_coverage", sid)
        covered.add(sid)
    if not m["reason"].strip():
        r.error("match.empty_reason")
    if m["status"] == "matched":
        if m["family_id"] not in registered_families:
            r.error("match.unknown_family")
        if covered != requirements or d["completeness"] != "complete":
            r.error("match.incomplete_coverage")
    else:
        for gap in m["uncovered_requirements"]:
            if (
                not gap["reason"].strip()
                or any(sid not in units for sid in gap["source_unit_refs"])
                or any(uid not in graph for uid in gap["domain_unit_refs"])
            ):
                r.error("match.invalid_uncovered_reference")
            elif not set(gap["source_unit_refs"]) <= {
                sid
                for uid in gap["domain_unit_refs"]
                for sid in graph[uid].get("source_unit_ids", [])
            }:
                r.error("match.unrelated_uncovered_reference")
    return r


class SolverReadinessChecker:
    """Step 3 adapter extension point. Contract validity never grants readiness."""

    def check(self, *args, **kwargs):
        raise NotImplementedError(
            "solver readiness adapters are not implemented for problem-domain/v2"
        )
