"""Model input optimization must preserve semantic and validation authority."""

import json
from copy import deepcopy
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from shuxueshuo_server.problem_understanding.authoring import (
    AUTO_COVERAGE,
    compact_schema,
    coverage_from_links,
    observation_view,
)
from shuxueshuo_server.problem_understanding.prompt import (
    SYSTEM,
    example,
    prompt_payload,
)
from shuxueshuo_server.problem_understanding.service import (
    parse_candidate,
    response_schema,
    seal_links,
)

FIXTURE = Path(__file__).parent / "fixtures/understanding-v2/k-quad"


def test_factored_schema_is_exactly_reversible():
    original = response_schema()
    packed = compact_schema(original)
    Draft202012Validator.check_schema(packed)
    generated = set(packed["$defs"]) - set(original["$defs"])

    def expand(value):
        if isinstance(value, list):
            return [expand(v) for v in value]
        if isinstance(value, dict):
            ref = value.get("$ref", "").removeprefix("#/$defs/")
            if ref in generated:
                return expand(packed["$defs"][ref])
            return {k: expand(v) for k, v in value.items()}
        return value

    restored = deepcopy(packed)
    restored["$defs"] = {
        k: v for k, v in restored["$defs"].items() if k not in generated
    }
    assert expand(restored) == original
    assert len(json.dumps(packed)) < len(json.dumps(original)) * 0.75


def test_unknown_observations_and_semantic_fields_are_preserved():
    observation = json.loads((FIXTURE / "observation.json").read_text())
    for state in ("unknown", "mixed", "handwritten"):
        row = deepcopy(observation["text_spans"][0])
        row.update(
            observation_id="independent-" + state,
            origin=state,
            block_id=None,
            polygon=[[0.8, 0.8], [0.9, 0.8], [0.9, 0.9]],
        )
        observation["text_spans"].append(row)
    original = deepcopy(observation)
    view, aliases = observation_view(observation)
    assert observation == original
    for group in (
        "layout_blocks",
        "text_spans",
        "formulas",
        "ink_origins",
        "occlusions",
    ):
        assert len(view[group]) == len(observation[group])
        for actual, expected in zip(view[group], observation[group], strict=True):
            assert aliases[actual["observation_id"]] == expected["observation_id"]
            for k in (
                "polygon",
                "origin",
                "confidence",
                "reading_order",
                "text",
                "latex",
                "status",
            ):
                if k in expected:
                    assert actual[k] == expected[k]
            assert "provider_id" not in actual and "source_artifact_id" not in actual
    assert view["issues"] and view["formulas"][0]["status"] == "unresolved"
    assert len(json.dumps(view)) < len(json.dumps(observation)) * 0.5


def test_independent_definition_example_uses_final_canonical_validator():
    wire = example()
    assert not list(
        Draft202012Validator(compact_schema(response_schema())).iter_errors(wire)
    )
    result = parse_candidate(
        json.dumps(wire),
        problem_id="example",
        source_sha256="0" * 64,
        registry_snapshot="0" * 64,
        registered_families=[],
    )
    assert result["contract_valid"], result["reports"]
    instances = result["reports"]["domain"]["expanded_instances"]
    assert (
        len(instances) == 2 and instances[0]["witnesses"] != instances[1]["witnesses"]
    )
    assert not result["solver_ready"]
    serialized = json.dumps(wire, ensure_ascii=False)
    assert "k-quad" not in serialized and "KQuad" not in serialized
    assert "四个独立图景" not in SYSTEM and "bbox" in SYSTEM and "Scope" in SYSTEM


@pytest.mark.parametrize("problem_id", ["unseen_geometry", "unseen_algebra"])
def test_prompt_is_not_selected_by_case(problem_id):
    p = prompt_payload(
        problem_id=problem_id,
        source_sha256="f" * 64,
        registry=[],
        observation={"pages": []},
    )
    assert p["identity"]["problem_id"] == problem_id
    assert p["legal_example_with_empty_example_registry"] == example()
    assert "k-quad" not in json.dumps(p)


def test_auto_coverage_only_inverts_declared_links():
    gold = json.loads((FIXTURE / "gold.json").read_text())
    wire = deepcopy(gold)
    wire["domain"]["coverage"] = AUTO_COVERAGE
    wire["domain"]["transcription_revision"] = "response.transcription"
    wire["match"]["transcription_revision"] = "response.transcription"
    wire["match"]["domain_revision"] = "response.domain"
    sealed = seal_links(wire)
    by_id = lambda rows: {r["source_unit_id"]: r for r in rows}
    assert by_id(sealed["domain"]["coverage"]) == by_id(gold["domain"]["coverage"])
    assert wire["domain"]["coverage"] == AUTO_COVERAGE
    # Missing source association must still fail coverage. No semantic recovery by code.
    scope = wire["domain"]["root"]["children"][1]
    scope["goals"] = []
    result = parse_candidate(
        json.dumps(wire),
        problem_id="k-quad",
        source_sha256=gold["transcription"]["source_sha256"],
        registry_snapshot="0" * 64,
        registered_families=[],
    )
    assert not result["contract_valid"]
    assert any(
        i["code"] == "coverage.missing_source_unit"
        for i in result["reports"]["domain"]["issues"]
    )


def test_auto_coverage_does_not_hide_gap_conflicts_or_bad_refs():
    domain = example()["domain"]
    domain["gaps"] = [
        {"id": "gap", "source_unit_id": "p1_given", "reason": "not encoded"}
    ]
    row = next(
        r for r in coverage_from_links(domain) if r["source_unit_id"] == "p1_given"
    )
    assert row["gap_id"] == "gap" and row["domain_unit_ids"]
    domain["root"]["children"][0]["entities"][0]["source_unit_ids"] = None
    # Malformed objects survive as candidates for their own schema-error report.
    wire = example()
    wire["domain"] = domain
    result = parse_candidate(
        json.dumps(wire),
        problem_id="example",
        source_sha256="0" * 64,
        registry_snapshot="0" * 64,
        registered_families=[],
    )
    assert (
        result["reports"]["transcription"]["ok"]
        and not result["reports"]["domain"]["ok"]
    )


@pytest.mark.parametrize(
    "reference,valid", [("q2.k", True), ("q2.A", False), ("q3.k", False)]
)
def test_scalar_argument_shorthand_preserves_types_and_scope(reference, valid):
    wire = json.loads((FIXTURE / "gold.json").read_text())
    wire["domain"]["coverage"] = AUTO_COVERAGE
    wire["domain"]["transcription_revision"] = "response.transcription"
    wire["match"]["transcription_revision"] = "response.transcription"
    wire["match"]["domain_revision"] = "response.domain"
    wire["domain"]["root"]["children"][1]["facts"][1]["relation"]["arguments"]["r"] = (
        reference
    )
    original = deepcopy(wire)
    result = parse_candidate(
        json.dumps(wire),
        problem_id="k-quad",
        source_sha256=wire["transcription"]["source_sha256"],
        registry_snapshot="0" * 64,
        registered_families=[],
    )
    assert result["contract_valid"] is valid
    assert wire == original
