"""Contract gates are independent of production registry and projection."""

import json
import subprocess
import sys
from copy import deepcopy
from pathlib import Path

import pytest

from shuxueshuo_server.problem_understanding.algebra import scalar_expression
from shuxueshuo_server.problem_understanding.contracts import (
    CONTRACTS,
    schema,
)
from shuxueshuo_server.problem_understanding.identity import revision, semantic_revision
from shuxueshuo_server.problem_understanding.service import (
    apply_repair,
    parse_candidate,
    render_candidate,
    response_schema,
)
from shuxueshuo_server.problem_understanding.validation import (
    DomainValidator,
    SolverReadinessChecker,
    validate_match,
    validate_transcription,
)
from shuxueshuo_server.solver.extraction.artifacts import ExtractionArtifactStore

FIXTURE = Path(__file__).parent / "fixtures/understanding-v2"


@pytest.fixture
def gold():
    return json.loads((FIXTURE / "k-quad/gold.json").read_text())


def validate(x):
    return DomainValidator().validate(x["domain"], x["transcription"])


def scopes(x):
    return x["domain"]["root"]["children"]


def q2(x):
    return scopes(x)[1]


def fact(x):
    return q2(x)["facts"][2]


def codes(r):
    return {i["code"] for i in r.issues}


def candidate(x, store=None):
    return parse_candidate(
        json.dumps(x),
        problem_id="k-quad",
        source_sha256=x["transcription"]["source_sha256"],
        registry_snapshot="0" * 64,
        registered_families=["testFamily"],
        store=store,
    )


def rebind(x):
    x["domain"]["transcription_revision"] = revision(x["transcription"])
    x["match"]["transcription_revision"] = revision(x["transcription"])
    x["match"]["domain_revision"] = revision(x["domain"])


def test_original_can_be_encoded_without_solver(gold):
    r = validate(gold)
    assert r.ok, r.issues
    assert len(r.expanded_instances) == 4
    assert len(gold["transcription"]["source_gaps"]) == 5
    first = r.expanded_instances[0]
    assert first["body"]["terms"][1]["second"] == ["q1.fig1.E", "q1.fig1.D"]
    assert first["witnesses"][0] != "q1.fig1.O"
    for i in r.expanded_instances:
        role_branches = i["body"]["terms"][2]["terms"]
        assert len(role_branches) == 2
        assert all(len(role["terms"][1]["terms"]) == 2 for role in role_branches)
    assert len({w for i in r.expanded_instances for w in i["witnesses"]}) == 4
    assert any(
        o["code"] == "nonzero_denominator" for o in r.well_definedness_obligations
    )
    assert candidate(gold)["contract_valid"]
    with pytest.raises(NotImplementedError):
        SolverReadinessChecker().check(gold)


def test_no_family_or_solver_import_in_fresh_process():
    script = """
import sys, importlib.abc
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self, fullname, *args):
  if fullname.startswith(('shuxueshuo_server.solver.family','shuxueshuo_server.solver.runtime','shuxueshuo_server.solver.projections')):
   raise AssertionError(fullname)
sys.meta_path.insert(0,Block())
import json
from shuxueshuo_server.problem_understanding.validation import DomainValidator
from shuxueshuo_server.problem_understanding.service import render_candidate
x=json.load(open(sys.argv[1]));r=DomainValidator().validate(x['domain'],x['transcription'])
assert r.ok,r.issues
assert 'k 倍四边形' in render_candidate(x['transcription'],x['domain'],r)
"""
    result = subprocess.run(
        [sys.executable, "-c", script, str(FIXTURE / "k-quad/gold.json")],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("case", sorted(FIXTURE.glob("tj*.json")), ids=lambda p: p.stem)
def test_five_new_expressions(case):
    x = json.loads(case.read_text())
    r = validate(x)
    assert r.ok, r.issues
    assert x["domain"]["completeness"] == "complete" and not x["domain"]["gaps"]
    assert semantic_revision(x["domain"]) == semantic_revision(
        json.loads(json.dumps(x["domain"]))
    )


@pytest.mark.parametrize(
    "field", ["solver_projection", "verified_problem", "adopted", "family_id"]
)
def test_forged_domain_fields_rejected(gold, field):
    gold["domain"][field] = {}
    result = candidate(gold)
    assert not result["reports"]["domain"]["ok"]
    assert result["reports"]["transcription"]["ok"]


@pytest.mark.parametrize(
    "mutation",
    [
        "null_domain",
        "empty_reason",
        "family_unmatched",
        "unknown_family",
        "false_coverage",
        "stale_registry",
        "unrelated_reason",
    ],
)
def test_match_contract_failures(gold, mutation):
    m = gold["match"]
    if mutation == "null_domain":
        gold["domain"] = None
    if mutation == "empty_reason":
        m["reason"] = " "
    if mutation == "family_unmatched":
        m["family_id"] = "testFamily"
    if mutation == "unknown_family":
        m.update(
            status="matched",
            family_id="notRegistered",
            uncovered_requirements=[],
            coverage=[
                {"requirement_ref": "q2.goal", "domain_unit_refs": ["q2.answer"]}
            ],
        )
    if mutation == "false_coverage":
        m["coverage"] = [
            {"requirement_ref": "q2.goal", "domain_unit_refs": ["q2.length.fact"]}
        ]
    if mutation == "stale_registry":
        m["registry_snapshot"] = "f" * 64
    if mutation == "unrelated_reason":
        m["uncovered_requirements"][0]["source_unit_refs"] = ["q2.goal"]
    result = candidate(gold)
    assert not result["contract_valid"]


@pytest.mark.parametrize(
    "mutation,code",
    [
        ("cross_scope", "reference.type_or_scope"),
        ("dimension", "quantity.dimension_mismatch"),
        ("number_angle", "quantity.dimension_mismatch"),
        ("tan90", "quantity.undefined_tangent"),
        ("zero", "quantity.zero_denominator"),
        ("fake_algebra", "reference.type_or_scope"),
        ("degenerate", "geometry.degenerate_angle_measure"),
        ("diagonal", "geometry.wrong_diagonal"),
        ("polygon_order", "geometry.wrong_diagonal"),
        ("cycle", "definition.cycle_or_depth"),
        ("missing_coverage", "coverage.missing_source_unit"),
        ("fake_coverage", "coverage.false_reference"),
        ("partial", "coverage.partial_without_gaps"),
        ("handwriting", "source.unconfirmed_condition"),
        ("stale", "domain.stale_transcription"),
        ("identity", "domain.stale_transcription"),
        ("literal_false", "quantity.literal_contradiction"),
    ],
)
def test_domain_failures(gold, mutation, code):
    f = fact(gold)["relation"]
    if mutation == "cross_scope":
        f["left"]["angle"][0] = "q3.B"
    if mutation == "dimension":
        f["right"] = {"kind": "segment_length", "segment": ["q2.A", "q2.B"]}
    if mutation == "number_angle":
        f["right"] = {"kind": "number", "value": "90"}
    if mutation == "tan90":
        f["right"] = {
            "kind": "tan",
            "angle": {"kind": "angle_constant", "value": "90", "unit": "degree"},
        }
    if mutation == "zero":
        f["right"] = {
            "kind": "divide",
            "numerator": {"kind": "number", "value": "1"},
            "denominator": {"kind": "number", "value": "0"},
        }
    if mutation == "fake_algebra":
        f["right"] = {"kind": "scalar_algebra", "expression": "q2_A", "refs": ["q2_A"]}
    if mutation == "degenerate":
        f["left"]["angle"] = ["q2.A", "q2.A", "q2.B"]
    if mutation == "diagonal":
        q2(gold)["facts"][0]["relation"]["bisector"] = ["q2.A", "q2.B"]
    if mutation == "polygon_order":
        q2(gold)["entities"][-1]["vertices"] = ["q2.A", "q2.C", "q2.B", "q2.D"]
    if mutation == "cycle":
        gold["domain"]["definitions"][0]["body"] = {
            "kind": "definition_use",
            "definition_ref": "KQuad",
            "arguments": {"P": "P", "r": {"kind": "scalar", "symbol_ref": "r"}},
        }
    if mutation == "missing_coverage":
        gold["domain"]["coverage"].pop()
    if mutation == "fake_coverage":
        gold["domain"]["coverage"][0]["domain_unit_ids"] = ["q2.answer"]
    if mutation == "partial":
        gold["domain"]["completeness"] = "partial"
    if mutation == "handwriting":
        gold["transcription"]["root"]["children"][1]["units"][1]["origin"] = (
            "handwritten"
        )
        rebind(gold)
    if mutation == "stale":
        gold["transcription"]["root"]["title"] = "changed"
    if mutation == "identity":
        gold["domain"]["problem_id"] = "wrong"
    if mutation == "literal_false":
        f.update(
            left={"kind": "number", "value": "1"},
            right={"kind": "number", "value": "2"},
        )
    r = validate(gold)
    assert code in codes(r), r.issues


@pytest.mark.parametrize(
    "text",
    [
        '__import__("os")',
        "x.__class__",
        "[x for x in y]",
        "sqrt(-1)",
        "1/0",
        "True",
        "lambda:1",
        "10**1000000",
        "2e1000",
        "x[0]",
    ],
)
def test_controlled_ast_rejects(text):
    with pytest.raises(ValueError):
        scalar_expression(text, ("x",) if "x" in text else ())


def test_exact_numbers():
    assert str(scalar_expression("0.1+1/5")) == "3/10"
    assert str(scalar_expression("sqrt(8)/2")) == "sqrt(2)"


def test_semantic_normalization(gold):
    original = semantic_revision(gold["domain"])
    f = fact(gold)["relation"]
    f["left"], f["right"] = f["right"], f["left"]
    f["left"]["terms"].reverse()
    f["left"]["terms"][1]["value"] = "4/2"
    assert semantic_revision(gold["domain"]) == original
    assert revision(gold["domain"]) != gold["match"]["domain_revision"]


def test_formal_renaming(gold):
    original = semantic_revision(gold["domain"])

    # Rename formal references and all instance argument keys, not source labels.
    def rename(x):
        if isinstance(x, dict):
            return {("ratio" if k == "r" else k): rename(v) for k, v in x.items()}
        if isinstance(x, list):
            return [rename(v) for v in x]
        return "ratio" if x == "r" else x

    gold["domain"] = rename(gold["domain"])
    assert validate(gold).ok
    assert semantic_revision(gold["domain"]) == original


@pytest.mark.parametrize(
    "mutation",
    ["angle", "ratio_direction", "polygon_order", "branch", "target", "scope"],
)
def test_semantic_changes_detected(gold, mutation):
    original = semantic_revision(gold["domain"])
    if mutation == "angle":
        fact(gold)["relation"]["right"]["terms"][0]["value"] = "3"
    if mutation == "ratio_direction":
        expr = gold["domain"]["root"]["children"][0]["children"][1]["goals"][0][
            "expression"
        ]
        expr["numerator"], expr["denominator"] = expr["denominator"], expr["numerator"]
    if mutation == "polygon_order":
        q2(gold)["entities"][-1]["vertices"].reverse()
    if mutation == "branch":
        gold["domain"]["definitions"][0]["body"]["terms"][2]["terms"].pop()
    if mutation == "target":
        q2(gold)["goals"][0]["expression"] = {"kind": "number", "value": "1"}
    if mutation == "scope":
        q2(gold)["part_ref"] = "q3"
    assert semantic_revision(gold["domain"]) != original


def test_repair_and_binding(gold):
    old = deepcopy(gold["domain"])
    f = fact(gold)
    patch = {
        "schema_version": "problem-repair/v2",
        "base_revision": revision(old),
        "replacements": [{"unit_id": f["id"], "value": deepcopy(f)}],
    }
    (
        patch["replacements"][0]["value"]["relation"]["left"],
        patch["replacements"][0]["value"]["relation"]["right"],
    ) = deepcopy(f["relation"]["right"]), deepcopy(f["relation"]["left"])
    new, r = apply_repair(
        old, gold["transcription"], patch, authorized_unit_ids={f["id"]}
    )
    assert r.ok and old == gold["domain"] and revision(old) != revision(new)
    assert semantic_revision(old) == semantic_revision(new)
    assert not validate_match(
        gold["match"],
        new,
        gold["transcription"],
        registry_snapshot="0" * 64,
        registered_families=[],
    ).ok
    for bad in ["stale", "cone", "source", "id", "cross_scope"]:
        p = deepcopy(patch)
        authorized = {f["id"]}
        if bad == "stale":
            p["base_revision"] = "f" * 64
        if bad == "cone":
            authorized = set()
        if bad == "source":
            p["replacements"][0]["value"]["source_unit_ids"] = []
        if bad == "id":
            p["replacements"][0]["value"]["id"] = "new"
        if bad == "cross_scope":
            p["replacements"][0]["value"]["relation"]["right"]["angle"][0] = "q3.A"
        with pytest.raises(ValueError):
            apply_repair(old, gold["transcription"], p, authorized_unit_ids=authorized)


def test_partial_save_and_safe_render(gold, tmp_path):
    store = ExtractionArtifactStore(tmp_path)
    first = candidate(gold, store)
    second = candidate(gold, store)
    assert first["artifacts"] == second["artifacts"]
    gold["domain"] = None
    r = candidate(gold, store)
    assert r["reports"]["transcription"]["ok"] and "transcription" in r["artifacts"]
    assert not r["contract_valid"] and not r["solver_ready"]
    for raw in ["{", "{} garbage", '{"a":1,"a":2}', "NaN"]:
        result = parse_candidate(
            raw,
            problem_id="k-quad",
            source_sha256="0" * 64,
            registry_snapshot="0" * 64,
            registered_families=[],
            store=store,
        )
        assert not result["reports"]["top"]["ok"]
        assert list(result["artifacts"]) == ["raw"]


def test_xss_and_no_guessed_answers(gold):
    gold["transcription"]["root"]["title"] = "<img src=x onerror=alert(1)>"
    html = render_candidate(gold["transcription"], gold["domain"], validate(gold))
    assert "<img" not in html and "&lt;img" in html and "待证明义务" in html


def test_limits(gold):
    f = fact(gold)["relation"]
    q = {"kind": "number", "value": "1"}
    for _ in range(34):
        q = {"kind": "tan", "angle": q}
    f["right"] = q
    assert not validate(gold).ok
    gold["domain"]["definitions"] *= 9
    assert not validate(gold).ok


def test_schema_snapshots_and_wire_refs(gold):
    for contract in CONTRACTS:
        assert json.loads(
            (FIXTURE / "schemas" / (contract.replace("/", "-") + ".json")).read_text()
        ) == schema(contract)
    from jsonschema import Draft202012Validator

    wire = deepcopy(gold)
    wire["domain"]["coverage"] = "from_source_unit_ids"
    wire["domain"]["transcription_revision"] = "response.transcription"
    wire["match"]["transcription_revision"] = "response.transcription"
    wire["match"]["domain_revision"] = "response.domain"
    assert not list(Draft202012Validator(response_schema()).iter_errors(wire))
    assert candidate(wire)["contract_valid"]
    wire["domain"]["problem_id"] = "forged"
    assert not candidate(wire)["contract_valid"]


def test_algebra_does_not_erase_domain_obligations():
    obligations = []
    assert str(scalar_expression("x/x", ["x"], obligations)) == "1"
    assert obligations == [{"code": "nonzero_algebra_denominator", "expression": "x"}]
    a = {"kind": "scalar_algebra", "expression": "x/x", "refs": ["x"]}
    b = {"kind": "scalar_algebra", "expression": "1+0*x", "refs": ["x"]}
    assert semantic_revision(a) != semantic_revision(b)
    obligations = []
    scalar_expression("sqrt(x)", ["x"], obligations)
    assert obligations[0]["code"] == "nonnegative_radicand"


def test_all_resource_limits(gold):
    from copy import deepcopy

    # Quantity node count, independently of expression depth.
    changed = deepcopy(gold)
    fact(changed)["relation"]["right"] = {
        "kind": "add",
        "terms": [{"kind": "number", "value": "1"} for _ in range(256)],
    }
    assert "quantity.resource_limit" in codes(validate(changed))
    # Expanded instances across a wide but schema-legal scope.
    changed = deepcopy(gold)
    s = q2(changed)
    original = s["facts"][1]
    for i in range(33):
        f = deepcopy(original)
        f["id"] = f"copy{i}"
        s["facts"].append(f)
    assert "definition.instance_limit" in codes(validate(changed))
    # Exponential definition expansion must stop, not truncate and accept.
    changed = deepcopy(gold)
    template = deepcopy(changed["domain"]["definitions"][0])
    body = template["body"]
    template["body"] = {"kind": "all", "terms": [deepcopy(body) for _ in range(100)]}
    changed["domain"]["definitions"] = [template]
    assert "definition.expansion_limit" in codes(validate(changed))
    # Dependency nesting is bounded separately from quantity nesting.
    changed = deepcopy(gold)
    for i in range(5):
        d = deepcopy(changed["domain"]["definitions"][0])
        d["id"] = f"def{i}"
        d["local_witnesses"] = []
        d["body"] = {
            "kind": "definition_use",
            "definition_ref": f"def{i + 1}" if i < 4 else "KQuad",
            "arguments": {"P": "P", "r": {"kind": "scalar", "symbol_ref": "r"}},
        }
        changed["domain"]["definitions"].append(d)
    assert "definition.cycle_or_depth" in codes(validate(changed))


def test_source_identity_and_regions(gold):
    t = gold["transcription"]
    for mutation in ["identity", "box", "page", "missing_gap"]:
        x = deepcopy(t)
        if mutation == "identity":
            x["problem_id"] = "forged"
        if mutation == "box":
            x["regions"][0]["bbox"] = [1, 0, 0, 1]
        if mutation == "page":
            x["regions"][0]["page"] = 2
        if mutation == "missing_gap":
            x["source_gaps"] = []
        assert not validate_transcription(
            x, problem_id="k-quad", source_sha256=t["source_sha256"]
        ).ok


def test_comparison_is_strict_but_id_independent(gold):
    from shuxueshuo_server.problem_understanding.comparison import compare

    original = deepcopy(gold["domain"])
    assert compare(original, original)["ok"]
    fact(gold)["relation"]["right"]["terms"][0]["value"] = "3"
    assert not compare(original, gold["domain"])["ok"]


def test_single_call_smoke_audit_and_resume(gold, tmp_path):
    from shuxueshuo_server.problem_understanding.identity import revision
    from shuxueshuo_server.problem_understanding.smoke import run
    from shuxueshuo_server.solver.extraction.multimodal_provider import (
        DeepSeekMultimodalExtractionProvider,
        MultimodalProviderResponse,
        ProviderSubAttempt,
    )

    class Fake:
        calls = 0
        # Reuse production preparation including image byte/hash/decode guards without a network client.
        model = "deepseek-flash"
        max_output_tokens = 16384
        request_timeout = 300
        prepare_request = DeepSeekMultimodalExtractionProvider.prepare_request

        def complete(self, request):
            self.calls += 1
            assert (
                request.thinking_mode == "enabled" and request.reasoning_effort == "low"
            )
            assert (
                request.images
                and request.images[0].artifact.sha256
                == gold["transcription"]["source_sha256"]
            )
            assert (
                request.stream is False
                and request.max_tokens == 16384
                and request.timeout == 300
            )
            gold["match"]["registry_snapshot"] = revision([])
            return MultimodalProviderResponse(
                text=json.dumps(gold),
                raw_payload={"offline_test": True},
                request_model="deepseek-flash",
                response_model="deepseek-flash",
                usage=None,
                finish_reason="stop",
                provider_attempts=(
                    ProviderSubAttempt(
                        provider_attempt=1,
                        status="completed",
                        response_model="deepseek-flash",
                        usage=None,
                        finish_reason="stop",
                        visible_content=True,
                        latency_ms=1,
                    ),
                ),
                latency_ms=1,
                thinking_mode="enabled",
                reasoning_effort="low",
            )

    fake = Fake()
    result = run(FIXTURE / "k-quad", tmp_path, fake, [])
    assert result["passed"], list(tmp_path.iterdir())
    assert (
        result["candidate_only"]
        and not result["source_reviewed"]
        and not result["solver_ready"]
    )
    assert json.loads((tmp_path / "call.json").read_text())["usage"] is None
    with pytest.raises(FileExistsError):
        run(FIXTURE / "k-quad", tmp_path, fake, [])
    assert fake.calls == 1


def test_smoke_failure_retained_and_not_repeated(tmp_path):
    from shuxueshuo_server.problem_understanding.smoke import run
    from shuxueshuo_server.solver.extraction.multimodal_provider import (
        DeepSeekMultimodalExtractionProvider,
    )

    class Failure:
        calls = 0
        model = "deepseek-flash"
        max_output_tokens = 16384
        request_timeout = 300
        prepare_request = DeepSeekMultimodalExtractionProvider.prepare_request

        def complete(self, request):
            self.calls += 1
            raise TimeoutError()

    p = Failure()
    r = run(FIXTURE / "k-quad", tmp_path, p, [])
    assert not r["passed"] and r["error_type"] == "TimeoutError" and p.calls == 1
    assert (tmp_path / "summary.json").exists()
    with pytest.raises(FileExistsError):
        run(FIXTURE / "k-quad", tmp_path, p, [])


def test_private_witness_requires_construction(gold):
    gold["domain"]["definitions"][0]["body"] = {
        "kind": "quantity_relation",
        "operator": ">=",
        "left": {"kind": "scalar", "symbol_ref": "r"},
        "right": {"kind": "number", "value": "1"},
    }
    assert "definition.unconstructed_witness" in codes(validate(gold))


def test_matched_still_cannot_grant_solver_readiness(gold):
    rows = [
        {
            "requirement_ref": row["source_unit_id"],
            "domain_unit_refs": row["domain_unit_ids"],
        }
        for row in gold["domain"]["coverage"]
        if row["source_unit_id"].endswith(".goal")
    ]
    gold["match"].update(
        status="matched",
        family_id="testFamily",
        coverage=rows,
        uncovered_requirements=[],
    )
    result = candidate(gold)
    assert (
        result["contract_valid"]
        and not result["solver_ready"]
        and not result["source_reviewed"]
    )


def test_empty_graph_rejected(gold):
    d = gold["domain"]
    d.update(definitions=[], coverage=[], gaps=[])
    d["root"].update(entities=[], facts=[], goals=[], children=[])
    assert "domain.empty_graph" in codes(validate(gold))


def test_malformed_formal_selector_reports_error_without_crashing(gold):
    gold["domain"]["definitions"][0]["body"]["terms"][1]["first"][0]["polygon"] = "r"
    result = candidate(gold)
    assert not result["contract_valid"]
    assert result["reports"]["transcription"]["ok"]
