# Independent understanding v2 fixtures

`k-quad/source.png` is the complete normalized image actually used by build
`6de57b87-fcd6-4977-8e99-2d3c4d7db01b`. Its SHA256 is
`7986e2751c53a4097599eb448623a9c87456179b2c0ce7e678f15623502d1038`.

`provenance.json` records both exported artifact hashes and sanitized fixture hashes.
The actual layout/text/formula calls, SourceObservation and Context are retained.
Filesystem locators, endpoints and request/trace fields are replaced where present.
Original observation confidence, coordinates, source categories and source hashes
are retained. These are recorded observations, not a live OCR integration.

The three `legacy-response-*`, `legacy-provider-*` and `legacy-validation-*` files
are failed model diagnostics. They are **not ground truth**. No business database
is needed to read these fixtures or run tests.

`author_gold.py` is the explicitly human-authored interpretation of the image.
It produces `k-quad/gold.json`, including four isolated scenarios and all four
branches of the parameterized definition. The actual image contains no figures
1–4; the square-like glyph preceding ABCD cannot reliably establish a square or
parallelogram. Five source gaps retain those four missing figures and the glyph.
The readable domain is complete; this does not establish that missing diagrams
are unnecessary or that the source has passed independent review.

`author_five.py` explicitly re-expresses the five existing human-authored golds
using typed v2 primitives. Every legacy primitive has an explicit mapping;
unknown primitives raise. This is fixture authoring only, not a production
adapter or data migration layer. Their existing source image hashes are bound in
the transcription. These fixtures demonstrate expression capacity; new adapter
projection and new-contract five-case live acceptance belong to Step 3.

`schemas/` are generated snapshots of `problem_understanding.contracts`; tests
compare them to that single source. The provider wire schema is generated from
these types too. Explicit `response.transcription` / `response.domain` links are
resolved by the server into exact revisions; a model is not asked to calculate
SHA256 of its own output. Incorrect supplied hashes/identities are rejected.

Re-author fixtures from repository root:

```sh
PYTHONPATH=server server/.venv/bin/python server/tests/solver/fixtures/understanding-v2/author_gold.py
PYTHONPATH=server server/.venv/bin/python server/tests/solver/fixtures/understanding-v2/author_five.py
```

Do not change frozen golds to make a live response pass. The single-call smoke
stores an exclusive durable reservation before transport; an existing run
folder cannot execute a second semantic call, including after a crash.
