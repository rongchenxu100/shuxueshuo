"""Human-authored source interpretation, not model output or a production adapter.

Run with PYTHONPATH=server python this file from the repository root.
"""

import json
from hashlib import sha256
from pathlib import Path

from shuxueshuo_server.problem_understanding.identity import revision

HERE = Path(__file__).parent


def n(v):
    return {"kind": "number", "value": str(v)}


def scalar(v):
    return {"kind": "scalar", "symbol_ref": v}


def length(a, b):
    return {"kind": "segment_length", "segment": [a, b]}


def angle(a, b, c):
    return {"kind": "angle_measure", "angle": [a, b, c], "unit": "degree"}


def area(a, b, c):
    return {"kind": "triangle_area", "vertices": [a, b, c], "convention": "unsigned"}


def mul(*xs):
    return {"kind": "multiply", "terms": list(xs)}


def rel(a, b, op="="):
    return {"kind": "quantity_relation", "operator": op, "left": a, "right": b}


def logic(k, *xs):
    return {"kind": k, "terms": list(xs)}


def unit(i, text, kind="condition"):
    return {"id": i, "kind": kind, "text": text, "region_refs": [], "origin": "printed"}


def part(i, title, units=(), children=()):
    return {"id": i, "title": title, "units": list(units), "children": list(children)}


def scope(i, part, entities=(), facts=(), goals=(), children=()):
    return {
        "id": i,
        "part_ref": part,
        "entities": list(entities),
        "facts": list(facts),
        "goals": list(goals),
        "children": list(children),
    }


def fact(i, r, s):
    return {"id": i, "relation": r, "source_unit_ids": [s]}


def goal(i, q, s, parameters=()):
    return {
        "id": i,
        "kind": "quantity_goal",
        "expression": q,
        "answer_form": {"kind": "expression_in", "parameters": list(parameters)}
        if parameters
        else {"kind": "exact_value"},
        "source_unit_ids": [s],
    }


def point(i, s, role="given"):
    return {
        "id": i,
        "kind": "point",
        "label": i.split(".")[-1],
        "role": role,
        "source_unit_ids": [s],
    }


def param(i, s):
    return {
        "id": i,
        "kind": "scalar",
        "label": i.split(".")[-1],
        "source_unit_ids": [s],
    }


def polygon(i, vs, s):
    return {
        "id": i,
        "kind": "polygon",
        "label": "".join(v.split(".")[-1] for v in vs),
        "vertices": vs,
        "source_unit_ids": [s],
    }


def use(poly, q):
    return {
        "kind": "definition_use",
        "definition_ref": "KQuad",
        "arguments": {"P": poly, "r": q},
    }


def save(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + "\n")


def kquad():
    v = lambda i: {"kind": "polygon_vertex", "polygon": "P", "index": i}
    X = "X"
    midpoint = lambda a, b: {"kind": "midpoint", "point": X, "segment": [v(a), v(b)]}
    ratio = lambda a, b: logic(
        "any",
        rel(length(v(a), X), mul(scalar("r"), length(X, v(b)))),
        rel(length(X, v(b)), mul(scalar("r"), length(v(a), X))),
    )
    definition = {
        "id": "KQuad",
        "label": "k 倍四边形",
        "parameters": [{"id": "P", "kind": "polygon"}, {"id": "r", "kind": "scalar"}],
        "local_witnesses": [{"id": "X", "kind": "point"}],
        "body": logic(
            "all",
            rel(scalar("r"), n(1), ">="),
            {
                "kind": "intersection",
                "point": X,
                "first": [v(0), v(2)],
                "second": [v(1), v(3)],
                "interior": True,
            },
            logic(
                "any",
                logic("all", midpoint(0, 2), ratio(1, 3)),
                logic("all", midpoint(1, 3), ratio(0, 2)),
            ),
        ),
        "source_unit_ids": ["definition.text"],
    }
    p1 = part(
        "q1.fig1",
        "（1）图 1",
        [
            unit(
                "q1.fig1.given", "如图1，在□ABCD中，对角线AC与BD交于点O，点E为OB中点。"
            ),
            unit("q1.fig1.symbol", "□ABCD 的符号形状无法可靠确定。", "text"),
            unit("q1.fig1.instance", "四边形AECD为k倍四边形。"),
            unit("q1.fig1.goal", "求k的值。", "requirement"),
        ],
    )
    p2 = part(
        "q1.fig2",
        "（1）图 2",
        [
            unit("q1.fig2.given", "如图2，在k倍四边形ABCD中，对角线AC被BD平分。"),
            unit("q1.fig2.goal", "求S△ACD/S△ACB，用含k的代数式表示。", "requirement"),
        ],
    )
    p3 = part(
        "q2",
        "（2）图 3",
        [
            unit("q2.given", "如图3，四边形ABCD为k倍四边形，其对角线BD平分对角线AC。"),
            unit("q2.angle", "∠BDC=2∠ABD。"),
            unit("q2.length", "BD=4CD。"),
            unit("q2.goal", "求k的值。", "requirement"),
        ],
    )
    p4 = part(
        "q3",
        "（3）图 4",
        [
            unit(
                "q3.points",
                "如图4，已知定点A、B，点D为平面内一点，连接A、B、C、D构成四边形ABCD。",
            ),
            unit("q3.perpendicular", "AB⊥BM。"),
            unit("q3.ray", "点C为射线BM上一动点。"),
            unit("q3.bisect", "BD平分AC。"),
            unit("q3.angle", "∠BAC=∠DAC。"),
            unit("q3.instance", "四边形ABCD为2倍四边形。"),
            unit("q3.goal", "求tan∠ACD的值。", "requirement"),
        ],
    )
    parts = [p1, p2, p3, p4]
    image_hash = sha256((HERE / "k-quad/source.png").read_bytes()).hexdigest()
    t = {
        "schema_version": "problem-transcription/v1",
        "problem_id": "k-quad",
        "source_sha256": image_hash,
        "root": part(
            "root",
            "定义与问题",
            [
                unit(
                    "definition.text",
                    "若四边形的一条对角线被另一条对角线平分，且另一条对角线被交点分成的两条线段长度之比为k（k≥1），则称该四边形为“k倍四边形”。",
                    "definition",
                )
            ],
            [part("q1", "（1）", children=[p1, p2]), p3, p4],
        ),
        "regions": [{"id": "page", "page": 1, "bbox": [0, 0, 1, 1]}],
        "figures": [
            {
                "id": f"figure{i}",
                "label": f"图{i}",
                "part_ref": p["id"],
                "available": False,
                "region_refs": [],
            }
            for i, p in enumerate(parts, 1)
        ],
        "source_gaps": [
            {
                "id": f"missing.figure{i}",
                "reason": "missing_figure",
                "description": f"题目文字引用图{i}，上传图片中未包含图示。",
                "part_ref": p["id"],
                "source_unit_refs": [],
                "region_refs": [],
            }
            for i, p in enumerate(parts, 1)
        ]
        + [
            {
                "id": "ambiguous.symbol",
                "reason": "ambiguous_symbol",
                "description": "□ABCD 的符号不能确认为平行四边形或正方形，保留原符号。",
                "part_ref": "q1.fig1",
                "source_unit_refs": ["q1.fig1.symbol"],
                "region_refs": ["page"],
            }
        ],
    }
    scopes = []
    for prefix in ["q1.fig1", "q1.fig2", "q2", "q3"]:
        sid = prefix + (".points" if prefix == "q3" else ".given")
        pt = lambda x, prefix=prefix: prefix + "." + x
        es = [
            point(
                pt(x),
                sid,
                "fixed"
                if prefix == "q3" and x in "AB"
                else "moving"
                if prefix == "q3" and x == "C"
                else "given",
            )
            for x in (
                "ABCDOE"
                if prefix == "q1.fig1"
                else "ABCDM"
                if prefix == "q3"
                else "ABCD"
            )
        ]
        if prefix != "q3":
            es.append(param(pt("k"), sid))
        es.append(polygon(pt("ABCD"), [pt(x) for x in "ABCD"], sid))
        fs = []
        if prefix == "q1.fig1":
            es.append(
                polygon(pt("AECD"), [pt(x) for x in "AECD"], prefix + ".instance")
            )
            fs = [
                fact(
                    prefix + ".intersection",
                    {
                        "kind": "intersection",
                        "point": pt("O"),
                        "first": [pt("A"), pt("C")],
                        "second": [pt("B"), pt("D")],
                        "interior": True,
                    },
                    sid,
                ),
                fact(
                    prefix + ".midpoint",
                    {
                        "kind": "midpoint",
                        "point": pt("E"),
                        "segment": [pt("O"), pt("B")],
                    },
                    sid,
                ),
                fact(
                    prefix + ".use",
                    use(pt("AECD"), scalar(pt("k"))),
                    prefix + ".instance",
                ),
            ]
        else:
            fs.append(
                fact(
                    prefix + ".bisects",
                    {
                        "kind": "diagonal_bisects",
                        "polygon": pt("ABCD"),
                        "bisector": [pt("B"), pt("D")],
                        "bisected": [pt("A"), pt("C")],
                    },
                    prefix + ".bisect" if prefix == "q3" else sid,
                )
            )
            fs.append(
                fact(
                    prefix + ".use",
                    use(pt("ABCD"), n(2) if prefix == "q3" else scalar(pt("k"))),
                    prefix + ".instance" if prefix == "q3" else sid,
                )
            )
        if prefix == "q2":
            fs.extend(
                [
                    fact(
                        "q2.angle.fact",
                        rel(
                            angle(pt("B"), pt("D"), pt("C")),
                            mul(n(2), angle(pt("A"), pt("B"), pt("D"))),
                        ),
                        "q2.angle",
                    ),
                    fact(
                        "q2.length.fact",
                        rel(
                            length(pt("B"), pt("D")),
                            mul(n(4), length(pt("C"), pt("D"))),
                        ),
                        "q2.length",
                    ),
                ]
            )
        if prefix == "q3":
            es.append(
                {
                    "id": pt("BM"),
                    "kind": "ray",
                    "label": "BM",
                    "endpoints": [pt("B"), pt("M")],
                    "source_unit_ids": ["q3.ray"],
                }
            )
            fs.extend(
                [
                    fact(
                        "q3.perp.fact",
                        {
                            "kind": "perpendicular",
                            "first": [pt("A"), pt("B")],
                            "second": [pt("B"), pt("M")],
                        },
                        "q3.perpendicular",
                    ),
                    fact(
                        "q3.ray.fact",
                        {"kind": "point_on_ray", "point": pt("C"), "ray": pt("BM")},
                        "q3.ray",
                    ),
                    fact(
                        "q3.angle.fact",
                        rel(
                            angle(pt("B"), pt("A"), pt("C")),
                            angle(pt("D"), pt("A"), pt("C")),
                        ),
                        "q3.angle",
                    ),
                ]
            )
        q = (
            {
                "kind": "divide",
                "numerator": area(pt("A"), pt("C"), pt("D")),
                "denominator": area(pt("A"), pt("C"), pt("B")),
            }
            if prefix == "q1.fig2"
            else {"kind": "tan", "angle": angle(pt("A"), pt("C"), pt("D"))}
            if prefix == "q3"
            else scalar(pt("k"))
        )
        gs = [
            goal(
                prefix + ".answer",
                q,
                prefix + ".goal",
                [pt("k")] if prefix == "q1.fig2" else [],
            )
        ]
        scopes.append(scope(prefix + ".scope", prefix, es, fs, gs))
    root = scope(
        "root.scope",
        "root",
        children=[scope("q1.scope", "q1", children=scopes[:2]), *scopes[2:]],
    )
    d = {
        "schema_version": "problem-domain/v2",
        "problem_id": "k-quad",
        "source_sha256": image_hash,
        "transcription_revision": revision(t),
        "completeness": "complete",
        "root": root,
        "definitions": [definition],
        "coverage": [],
        "gaps": [],
    }
    allunits = [definition]
    for s in scopes:
        allunits += s["entities"] + s["facts"] + s["goals"]
    for p in [t["root"], *parts]:
        for u in p["units"]:
            if u["kind"] != "text":
                d["coverage"].append(
                    {
                        "source_unit_id": u["id"],
                        "domain_unit_ids": [
                            x["id"] for x in allunits if u["id"] in x["source_unit_ids"]
                        ],
                        "gap_id": None,
                    }
                )
    m = {
        "schema_version": "problem-solver-match/v1",
        "status": "unmatched",
        "family_id": None,
        "transcription_revision": revision(t),
        "domain_revision": revision(d),
        "registry_snapshot": "0" * 64,
        "reason": "当前注册能力不覆盖题内四边形逻辑定义、面积比和正切要求。",
        "coverage": [],
        "uncovered_requirements": [
            {
                "source_unit_refs": ["definition.text"],
                "domain_unit_refs": ["KQuad"],
                "reason": "需要实例化并求解带 any 分支的题内几何定义。",
            }
        ],
    }
    return {
        "schema_version": "problem-understanding/v1",
        "transcription": t,
        "domain": d,
        "match": m,
    }


if __name__ == "__main__":
    save(HERE / "k-quad/gold.json", kquad())
