"""Auditable fixture authoring from the five existing human-authored domain golds.

This script is test data tooling, not a production adapter or old-data reader.
Every primitive is explicitly mapped; unknown primitives raise, never disappear.
"""

import re

from author_gold import *

ROOT = HERE.parents[4]


def author(old):
    case = old["problem_id"]
    image = json.loads(
        (ROOT / "internal/source-images" / case / "source-manifest.json").read_text()
    )["pages"][0]["sha256"]
    coverage = []

    def convert(s, env, prefix):
        sid = prefix + ".source"
        env = dict(env)
        for e in s["entities"]:
            env[e["id"]] = prefix.replace(".", "_") + "_" + e["id"]
        # dependent coordinate variable is explicit, even where the legacy curve stored only y=f(x).
        if prefix == "problem":
            env["y"] = "problem_y"
        ids = lambda x: env[x]

        def q(text):
            symbols = set(re.findall(r"\b[A-Za-z][A-Za-z0-9_]*\b", text)) - {"sqrt"}
            return (
                {
                    "kind": "scalar_algebra",
                    "expression": re.sub(
                        r"\b[A-Za-z][A-Za-z0-9_]*\b",
                        lambda m: env.get(m[0], m[0]),
                        text,
                    ),
                    "refs": sorted(ids(x) for x in symbols),
                }
                if symbols
                else n(text)
            )

        def seg(v):
            return [ids(v["start"]), ids(v["end"])]

        def ang(v):
            return angle(ids(v["start"]), ids(v["vertex"]), ids(v["end"]))

        def term(v):
            return mul(
                q(v["scale"]), {"kind": "segment_length", "segment": seg(v["segment"])}
            )

        def path(v):
            return {"kind": "add", "terms": [term(x) for x in v["terms"]]}

        def comp(p, axis):
            return {"kind": "coordinate_component", "point": ids(p), "axis": axis}

        es = []
        for e in s["entities"]:
            k = e["kind"]
            eid = ids(e["id"])
            if k == "point":
                v = point(eid, sid)
            elif k == "symbol":
                v = param(eid, sid)
            elif k == "quadratic_function":
                v = {
                    "id": eid,
                    "kind": "curve",
                    "label": e["label"],
                    "source_unit_ids": [sid],
                }
            elif k == "polygon":
                v = polygon(eid, [ids(x) for x in e["vertices"]], sid)
            elif k in ("ray", "named_ray"):
                v = {
                    "id": eid,
                    "kind": "ray",
                    "label": e["label"],
                    "endpoints": [ids(e["origin"]), ids(e["through"])],
                    "source_unit_ids": [sid],
                }
            else:
                raise ValueError(e)
            v["label"] = e["label"]
            es.append(v)
        if prefix == "problem":
            es.append(param("problem_y", sid))
        moving = [ids(e["id"]) for e in s["entities"] if e["kind"] == "point"] or [
            v for k, v in env.items() if k not in ("parabola", "square_AEKG", "CD")
        ][-1:]

        def relation(f):
            k = f["kind"]
            if k == "function_expression":
                return {
                    "kind": "curve_equation",
                    "curve": ids(f["function"]),
                    "expression": q(f["expression"]),
                    "independent": ids(f["variable"]),
                    "dependent": ids("y"),
                }
            if k == "symbol_value":
                return rel(scalar(ids(f["symbol"])), q(f["value"]))
            if k == "symbol_constraint":
                return rel(scalar(ids(f["symbol"])), q(f["value"]), f["operator"])
            if k == "equation":
                a, b = f["expression"].split("=")
                return rel(q(a.strip()), q(b.strip()))
            if k == "point_coordinate":
                return {
                    "kind": "coordinates",
                    "point": ids(f["point"]),
                    "x": q(f["value"][0]),
                    "y": q(f["value"][1]),
                }
            if k == "point_construction":
                c = f["construction"]
                p = ids(f["point"])
                if c == "origin":
                    return {"kind": "origin", "point": p}
                if c == "translated_point":
                    return {
                        "kind": "translation",
                        "point": p,
                        "original": ids(f["owner"]),
                        "vector": [q(x) for x in f["vector"]],
                    }
                if c == "curve_at_x":
                    return {
                        "kind": "curve_at_x",
                        "point": p,
                        "curve": ids(f["owner"]),
                        "x": q(f["x_expression"]),
                    }
                return {
                    "kind": "curve_landmark",
                    "point": p,
                    "curve": ids(f["owner"]),
                    "landmark": c,
                    "side": f.get("side"),
                    "exclude_point": ids(f["exclude_point"])
                    if f.get("exclude_point")
                    else None,
                }
            if k == "point_on_curve":
                return {"kind": k, "point": ids(f["point"]), "curve": ids(f["curve"])}
            if k == "point_on_curve_with_x":
                return logic(
                    "all",
                    {
                        "kind": "curve_at_x",
                        "point": ids(f["point"]),
                        "curve": ids(f["curve"]),
                        "x": scalar(ids(f["x_symbol"])),
                    },
                    rel(scalar(ids(f["x_symbol"])), q(f["x_range"][0]), ">"),
                    rel(scalar(ids(f["x_symbol"])), q(f["x_range"][1]), "<"),
                )
            if k == "quadrant_membership":
                assert f["quadrant"] == "第四象限"
                return logic(
                    "all",
                    rel(comp(f["point"], "x"), n(0), ">"),
                    rel(comp(f["point"], "y"), n(0), "<"),
                )
            if k == "right_angle":
                return rel(
                    ang(f["angle"]),
                    {"kind": "angle_constant", "value": "90", "unit": "degree"},
                )
            if k == "angle_sum":
                return rel(
                    {"kind": "add", "terms": [ang(v) for v in f["angles"]]},
                    {"kind": "angle_constant", "value": f["value"], "unit": "degree"},
                )
            if k == "equal_length":
                return rel(
                    {"kind": "segment_length", "segment": seg(f["left"])},
                    {"kind": "segment_length", "segment": seg(f["right"])},
                )
            if k == "length_relation":
                return rel(term(f["left"]), term(f["right"]))
            if k == "length_value":
                assert f["power"] == 1
                return rel(
                    {"kind": "segment_length", "segment": seg(f["segment"])},
                    {
                        "kind": "measured_constant",
                        "value": f["value"],
                        "unit": "length",
                    },
                )
            if k in ("midpoint", "point_on_segment"):
                return {
                    "kind": k,
                    "point": ids(f["point"]),
                    "segment": seg(f["segment"]),
                    **({"interior": False} if k == "point_on_segment" else {}),
                }
            if k == "point_on_ray":
                return {"kind": k, "point": ids(f["point"]), "ray": ids(f["ray"])}
            if k == "point_on_axis":
                return {
                    "kind": k,
                    "point": ids(f["point"]),
                    "axis": f["axis"],
                    "curve": ids(f["curve"]) if f.get("curve") else None,
                }
            if k == "square":
                return logic(
                    "all",
                    {"kind": "square", "polygon": ids(f["polygon"])},
                    rel(comp(f["orientation"]["point"], "y"), n(0), "<"),
                )
            if k == "square_center":
                return {
                    "kind": "midpoint",
                    "point": ids(f["point"]),
                    "segment": [ids("A"), ids("K")],
                }
            if k in ("minimum_target", "minimum_value_given"):
                return {
                    "kind": "extremum_constraint",
                    "direction": "minimum",
                    "expression": path(f["expression"]),
                    "variables": moving,
                    "value": {
                        "kind": "measured_constant",
                        "value": f["value"],
                        "unit": "length",
                    }
                    if k == "minimum_value_given"
                    else None,
                }
            raise ValueError(f)

        fs = [
            fact(prefix + f".fact{i}", relation(f), sid)
            for i, f in enumerate(s["facts"])
        ]
        us = [
            unit(sid, "\n".join(s["source_text"]), "condition" if es or fs else "text")
        ]
        gs = []
        for i, g in enumerate(s["goals"]):
            guid = prefix + f".goal{i}"
            source = guid + ".source"
            us.append(
                unit(
                    source,
                    "\n".join(s["source_text"]) + "【所求：" + g["answer_key"] + "】",
                    "requirement",
                )
            )
            if g["kind"] == "point_coordinate":
                v = {
                    "id": guid,
                    "kind": "coordinates_goal",
                    "point": ids(g["target"]),
                    "source_unit_ids": [source],
                }
            elif g["kind"] == "quadratic_equation":
                v = {
                    "id": guid,
                    "kind": "equation_goal",
                    "curve": ids(g["target"]),
                    "source_unit_ids": [source],
                }
            elif g["kind"] == "parameter_value":
                v = goal(guid, scalar(ids(g["target"])), source)
            elif g["kind"] == "minimum_value":
                v = {
                    "id": guid,
                    "kind": "extremum_goal",
                    "expression": path(g["expression"]),
                    "direction": "minimum",
                    "variables": moving,
                    "constraints": [],
                    "answer_form": {"kind": "exact_value"},
                    "source_unit_ids": [source],
                }
            else:
                raise ValueError(g)
            gs.append(v)
        cs = [convert(c, env, prefix + "." + c["id"]) for c in s["children"]]
        p = part(prefix, s["label"], us, [x[0] for x in cs])
        d = scope(prefix + ".scope", prefix, es, fs, gs, [x[1] for x in cs])
        for u in [u for u in us if u["kind"] != "text"]:
            coverage.append(
                {
                    "source_unit_id": u["id"],
                    "domain_unit_ids": [
                        v["id"] for v in es + fs + gs if u["id"] in v["source_unit_ids"]
                    ],
                    "gap_id": None,
                }
            )
        return p, d

    p, root = convert(old["root"], {}, "problem")
    t = {
        "schema_version": "problem-transcription/v1",
        "problem_id": case,
        "source_sha256": image,
        "root": p,
        "regions": [],
        "figures": [],
        "source_gaps": [],
    }
    d = {
        "schema_version": "problem-domain/v2",
        "problem_id": case,
        "source_sha256": image,
        "transcription_revision": revision(t),
        "completeness": "complete",
        "root": root,
        "definitions": [],
        "coverage": coverage,
        "gaps": [],
    }
    return {
        "transcription": t,
        "domain": d,
        "authorship": "human-authored v1 gold re-expressed with explicit primitive mappings; no adapter/readiness acceptance",
    }


if __name__ == "__main__":
    for p in sorted((ROOT / "internal/problem-domain-fixtures").glob("tj*.json")):
        save(HERE / (p.stem + ".json"), author(json.loads(p.read_text())))
